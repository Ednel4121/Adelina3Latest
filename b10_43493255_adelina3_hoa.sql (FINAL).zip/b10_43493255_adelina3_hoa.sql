-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql213.byetcluster.com
-- Generation Time: Nov 27, 2026 at 01:21 PM
-- Server version: 11.4.14-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b10_43493255_adelina3_hoa`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `body` text NOT NULL,
  `image_file` varchar(100) DEFAULT NULL,
  `image_data` mediumblob DEFAULT NULL,
  `image_mime` varchar(100) DEFAULT NULL,
  `date_posted` datetime DEFAULT current_timestamp(),
  `posted_by` int(11) DEFAULT NULL,
  `category` varchar(30) NOT NULL DEFAULT 'General'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcement_id`, `title`, `body`, `image_file`, `image_data`, `image_mime`, `date_posted`, `posted_by`, `category`) VALUES
(22, 'sadsa', 'asdas', NULL, NULL, NULL, '2026-11-26 07:42:18', 3, 'General');

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `log_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`log_id`, `user_id`, `action`, `details`, `created_at`) VALUES
(40, 3, 'clear_audit_log', 'Binura ang audit log.', '2026-11-22 05:23:20'),
(41, 3, 'validate_payment', 'Approved ang payment (payment_id=22).', '2026-11-22 05:29:33'),
(42, 3, 'delete_payment', 'Binura ang payment (payment_id=21).', '2026-11-22 05:29:54'),
(43, 3, 'remove_resident', 'Tinanggal ang resident (resident_id=21, user_id=29).', '2026-11-23 11:33:25'),
(44, 3, 'remove_resident', 'Tinanggal ang resident (resident_id=22, user_id=30).', '2026-11-23 11:38:10'),
(45, 3, 'remove_resident', 'Tinanggal ang resident (resident_id=27, user_id=36).', '2026-11-23 11:38:13'),
(46, 3, 'delete_complaint', 'Binura ang complaint (complaint_id=19).', '2026-11-23 12:37:02'),
(47, 3, 'delete_complaint', 'Binura ang complaint (complaint_id=20).', '2026-11-23 12:37:03'),
(48, 3, 'clear_payments', 'Binura ang lahat ng payment history.', '2026-11-26 07:34:27'),
(49, 3, 'record_payment', 'Nag-record ng 1,000.00 na bayad para sa resident_id=30 (HOA Dues).', '2026-11-26 07:38:08'),
(50, 3, 'approve_reservation', 'Approved ang reservation (reservation_id=16).', '2026-11-26 07:42:23'),
(51, 3, 'approve_resident', 'Na-approve ang resident account (user_id=40).', '2026-11-26 23:44:06'),
(52, 3, 'approve_reservation', 'Approved ang reservation (reservation_id=17).', '2026-11-26 23:52:08'),
(53, 3, 'remove_resident', 'Tinanggal ang resident (resident_id=28, user_id=37).', '2026-11-27 10:01:09'),
(54, 3, 'approve_resident', 'Na-approve ang resident account (user_id=41).', '2026-11-27 10:01:49');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `complaint_id` int(11) NOT NULL,
  `resident_id` int(11) NOT NULL,
  `report_type` varchar(20) NOT NULL DEFAULT 'Complaint',
  `category` varchar(50) DEFAULT NULL,
  `other_specify` varchar(100) DEFAULT NULL,
  `subject` varchar(150) NOT NULL,
  `details` text DEFAULT NULL,
  `status` enum('Pending','In Progress','Resolved') DEFAULT 'Pending',
  `officer_response` text DEFAULT NULL,
  `attachment_file` varchar(64) DEFAULT NULL,
  `attachment_name` varchar(255) DEFAULT NULL,
  `attachment_data` mediumblob DEFAULT NULL,
  `attachment_mime` varchar(100) DEFAULT NULL,
  `date_filed` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`complaint_id`, `resident_id`, `report_type`, `category`, `other_specify`, `subject`, `details`, `status`, `officer_response`, `attachment_file`, `attachment_name`, `attachment_data`, `attachment_mime`, `date_filed`) VALUES
(21, 30, 'Complaint', 'Others: walal', NULL, 'Complaint - Others: walal (Blk 1 Lot 23 - panget)', 'bjhgh', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-25 16:29:19'),
(22, 30, 'Complaint', 'Others', 'walal', 'b4 l5', 'sdas', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:18:00'),
(23, 30, 'Complaint', 'Noise', '', 'asd', 'asd', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:25:38'),
(24, 30, 'Complaint', 'Noise', '', 'asd', 'asd', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:25:43'),
(25, 30, 'Complaint', 'Noise', '', 'asd', 'sad', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:25:48'),
(26, 30, 'Complaint', 'Noise', '', 'sadasd', 'asd', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:25:52'),
(27, 30, 'Complaint', 'Noise', '', 'asd', 'asd', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:25:55'),
(28, 30, 'Complaint', 'Noise', '', 'asd', 'asd', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:25:58'),
(29, 30, 'Complaint', 'Noise', '', 'asdasd', 'asd', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:26:03'),
(30, 30, 'Complaint', 'Noise', '', 'asd', 'asd', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:26:10'),
(31, 30, 'Complaint', 'Noise', '', 'asdasd', 'sad', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:26:36'),
(32, 30, 'Complaint', 'Noise', '', 'qw4e', 'wqe', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 07:26:44'),
(33, 31, 'Complaint', 'Noise', '', 'Dito', 'ANG INGAY!!', 'Pending', NULL, NULL, '', NULL, NULL, '2026-11-26 23:47:42');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `attempt_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `attempted_at` datetime NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`attempt_id`, `email`, `attempted_at`, `success`) VALUES
(101, 'jianmateo123@gmail.com', '2026-11-26 23:41:45', 0),
(102, 'jianmateo123@gmail.com', '2026-11-26 23:41:51', 0),
(103, 'jianmateo123@gmail.com', '2026-11-26 23:41:55', 0),
(104, 'jianmateo123@gmail.com', '2026-11-26 23:42:01', 0),
(105, 'admin@gmail.com', '2026-11-26 23:42:34', 1),
(106, 'admin@gmail.com', '2026-11-26 23:43:51', 0),
(107, 'admin@gmail.com', '2026-11-26 23:43:53', 0),
(108, 'admin@gmail.com', '2026-11-26 23:43:58', 0),
(109, 'admin@gmail.com', '2026-11-26 23:44:02', 1),
(110, 'mateocharls21@yahoo.com', '2026-11-26 23:44:34', 1),
(111, 'admin@gmail.com', '2026-11-26 23:49:18', 1),
(112, 'mateocharls21@yahoo.com', '2026-11-26 23:57:43', 1),
(113, 'admin@gmail.com', '2026-11-26 16:02:14', 1),
(114, 'admin@gmail.com', '2026-11-26 16:02:18', 1),
(115, 'admin@gmail.com', '2026-11-26 16:15:50', 1),
(116, 'mateocharls21@yahoo.com', '2026-11-26 19:57:00', 0),
(117, 'mateocharls21@yahoo.com', '2026-11-26 19:57:11', 1),
(118, 'admin@gmail.com', '2026-11-26 20:40:28', 1),
(119, 'admin@gmail.com', '2026-11-26 20:40:31', 1),
(120, 'admin@gmail.com', '2026-11-26 20:40:40', 1),
(121, 'admin@gmail.com', '2026-11-26 20:45:56', 1),
(122, 'admin@gmail.com', '2026-11-26 20:45:58', 1),
(123, 'admin@gmail.com', '2026-11-26 20:46:06', 1),
(124, 'admin@gmail.com', '2026-11-26 21:43:16', 1),
(125, 'jianmateo123@gmail.com', '2026-11-26 21:43:43', 0),
(126, 'mateocharls21@yahoo.com', '2026-11-26 21:44:02', 1),
(127, 'ednel.arancillo@cvsu.edu.ph', '2026-11-26 21:47:08', 1),
(128, 'admin@gmail.com', '2026-11-27 00:05:02', 1),
(129, 'admin@gmail.com', '2026-11-27 05:12:40', 1),
(130, 'admin@gmail.com', '2026-11-27 07:07:07', 1),
(131, 'mateocharls21@yahoo.com', '2026-11-27 07:35:52', 1),
(132, 'admin@gmail.com', '2026-11-27 07:37:32', 1),
(133, 'mateocharls21@yahoo.com', '2026-11-27 07:40:45', 0),
(134, 'mateocharls21@yahoo.com', '2026-11-27 07:40:54', 1),
(135, 'admin@gmail.com', '2026-11-27 07:56:31', 1),
(136, 'mateocharls21@yahoo.com', '2026-11-27 08:40:44', 0),
(137, 'admin@gmail.com', '2026-11-27 08:41:02', 0),
(138, 'admin@gmail.com', '2026-11-27 08:42:10', 1),
(139, 'admin@gmail.com', '2026-11-27 08:46:03', 1),
(140, 'admin@gmail.com', '2026-11-27 09:04:19', 1),
(141, 'admin@gmail.com', '2026-11-27 09:58:47', 1),
(142, 'admin@gmail.com', '2026-11-27 10:01:03', 1),
(143, 'admin@gmail.com', '2026-11-27 10:01:46', 1),
(144, 'admin@gmail.com', '2026-11-27 10:09:15', 1),
(145, 'ednelarancillo@gmail.com', '2026-11-27 10:17:29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `type`, `title`, `message`, `link`, `is_read`, `created_at`) VALUES
(1, 37, 'complaint', 'May update sa complaint mo', 'Ang complaint mo na \"KAPITBAHAY MAINGAY\" ay Resolved na.', 'complaints.php', 1, '2026-11-22 11:57:37'),
(2, 37, 'reservation', 'Na-approve ang reservation mo', 'Na-approve ang reservation mo sa Clubhouse sa 2026-11-23 23:30:00.', 'reservations.php', 1, '2026-11-22 12:01:30'),
(3, 37, 'payment', 'Na-approve ang payment mo', 'Na-approve ang payment mo para sa utang na loob (₱1,000.00). Na-mark ito bilang Paid.', 'payments.php', 1, '2026-11-22 12:05:47'),
(4, 36, 'complaint', 'May update sa complaint mo', 'Ang complaint mo na \"kase\" ay In Progress na. Sagot ng officer: ako na diparen naliligo bukas nako', 'complaints.php', 0, '2026-11-22 12:11:18'),
(5, 36, 'reservation', 'Na-approve ang reservation mo', 'Na-approve ang reservation mo sa Basketball Court sa 2026-12-24 18:00:00.', 'reservations.php', 0, '2026-11-22 12:14:44'),
(6, 37, 'payment', 'Na-approve ang payment mo', 'Na-approve ang payment mo para sa HOA Dues (₱1,000.00). Na-mark ito bilang Paid.', 'payments.php', 1, '2026-11-22 13:29:33'),
(7, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: Complaint - Noise (Blk 1 Lot 23 - panget)', 'complaints.php', 1, '2026-11-23 04:03:16'),
(8, 39, 'complaint', 'May update sa complaint mo', 'Ang complaint mo na \"Complaint - Noise (Blk 1 Lot 23 - panget)\" ay Resolved na.', 'complaints.php', 1, '2026-11-23 04:26:47'),
(9, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: Complaint - Parking (Blk 1 Lot 23 - panget)', 'complaints.php', 1, '2026-11-23 04:27:23'),
(10, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: Complaint - Others: walal (Blk 1 Lot 23 - panget)', 'complaints.php', 1, '2026-11-25 08:29:19'),
(11, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: b4 l5', 'complaints.php', 1, '2026-11-25 23:18:00'),
(12, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asd', 'complaints.php', 1, '2026-11-25 23:25:38'),
(13, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asd', 'complaints.php', 1, '2026-11-25 23:25:43'),
(14, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asd', 'complaints.php', 1, '2026-11-25 23:25:48'),
(15, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: sadasd', 'complaints.php', 1, '2026-11-25 23:25:52'),
(16, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asd', 'complaints.php', 1, '2026-11-25 23:25:55'),
(17, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asd', 'complaints.php', 1, '2026-11-25 23:25:58'),
(18, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asdasd', 'complaints.php', 1, '2026-11-25 23:26:03'),
(19, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asd', 'complaints.php', 1, '2026-11-25 23:26:10'),
(20, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: asdasd', 'complaints.php', 1, '2026-11-25 23:26:36'),
(21, 3, 'complaint', 'Bagong reklamo', 'Ramon Julius Alday: qw4e', 'complaints.php', 1, '2026-11-25 23:26:44'),
(22, 3, 'reservation', 'Bagong reservation', 'Ramon Julius Alday — Clubhouse, Nov 28, 2026 5:00 AM - 5:00 PM', 'reservations.php', 1, '2026-11-25 23:41:39'),
(23, 37, 'announcement', 'Bagong announcement', 'sadsa', 'announcements.php', 1, '2026-11-25 23:42:18'),
(24, 38, 'announcement', 'Bagong announcement', 'sadsa', 'announcements.php', 0, '2026-11-25 23:42:18'),
(25, 39, 'announcement', 'Bagong announcement', 'sadsa', 'announcements.php', 0, '2026-11-25 23:42:18'),
(26, 39, 'reservation', 'Na-approve ang reservation mo', 'Na-approve ang reservation mo sa Clubhouse sa 2026-11-28 5:00 AM - 5:00 PM.', 'reservations.php', 0, '2026-11-25 23:42:23'),
(27, 3, 'payment', 'Bagong bayad', 'Ramon Julius Alday — Cash', 'payments.php', 1, '2026-11-25 23:52:42'),
(28, 3, 'registration', 'Bagong rehistro', 'Jian Mateo — Blk 1 Lot 1, Ilaya St. (naghihintay ng approval)', 'residents.php', 1, '2026-11-26 15:43:36'),
(29, 3, 'complaint', 'Bagong reklamo', 'Jian Mateo: Dito', 'complaints.php', 1, '2026-11-26 15:47:42'),
(30, 3, 'reservation', 'Bagong reservation', 'Jian Mateo — Clubhouse, Nov 27, 2026 9:00 AM - 9:00 PM', 'reservations.php', 1, '2026-11-26 15:48:16'),
(31, 40, 'reservation', 'Na-approve ang reservation mo', 'Na-approve ang reservation mo sa Clubhouse sa 2026-11-27 9:00 AM - 9:00 PM.', 'reservations.php', 1, '2026-11-26 15:52:08'),
(32, 3, 'registration', 'Bagong rehistro', 'Ednel Arancillo â€” Blk 1 Lot 4, KAGOSHIMA (naghihintay ng approval)', 'residents.php', 0, '2026-11-27 18:01:40');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `resident_id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date_paid` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('Paid','Unpaid') DEFAULT 'Unpaid',
  `approval_status` enum('Pending','Approved','Rejected') DEFAULT NULL,
  `payment_method` enum('Cash','Online Payment') DEFAULT NULL,
  `payment_provider` varchar(50) DEFAULT NULL,
  `payment_reference` varchar(100) DEFAULT NULL,
  `payment_proof` varchar(255) DEFAULT NULL,
  `payment_proof_data` mediumblob DEFAULT NULL,
  `payment_proof_mime` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `resident_id`, `description`, `amount`, `date_paid`, `due_date`, `status`, `approval_status`, `payment_method`, `payment_provider`, `payment_reference`, `payment_proof`, `payment_proof_data`, `payment_proof_mime`) VALUES
(23, 30, 'HOA Dues', '1000.00', NULL, '2026-12-26', 'Unpaid', 'Pending', 'Cash', NULL, '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(11) NOT NULL,
  `resident_id` int(11) NOT NULL,
  `facility` enum('Clubhouse','Basketball Court','Park Area') NOT NULL,
  `date_reserved` date NOT NULL,
  `time_reserved` time DEFAULT NULL,
  `time_to` time DEFAULT NULL,
  `purpose` varchar(150) DEFAULT NULL,
  `status` enum('Pending','Approved','Not Approved') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `resident_id`, `facility`, `date_reserved`, `time_reserved`, `time_to`, `purpose`, `status`) VALUES
(16, 30, 'Clubhouse', '2026-11-28', '05:00:00', '17:00:00', 'wdas', 'Approved'),
(17, 31, 'Clubhouse', '2026-11-27', '09:00:00', '21:00:00', 'Secret', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `residents`
--

CREATE TABLE `residents` (
  `resident_id` int(11) NOT NULL,
  `blk` tinyint(3) UNSIGNED NOT NULL,
  `lot` tinyint(3) UNSIGNED NOT NULL,
  `street` varchar(100) NOT NULL DEFAULT '',
  `user_id` int(11) DEFAULT NULL,
  `block_lot` varchar(50) NOT NULL,
  `household_members` int(11) DEFAULT 1,
  `move_in_date` date DEFAULT NULL,
  `status` enum('active','moved out') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `residents`
--

INSERT INTO `residents` (`resident_id`, `blk`, `lot`, `street`, `user_id`, `block_lot`, `household_members`, `move_in_date`, `status`) VALUES
(29, 0, 0, '', 38, 'block 100 lot 1000', 150, NULL, 'active'),
(30, 1, 23, '', 39, 'Blk 1 Lot 23 - panget', 4, '2003-02-04', 'active'),
(31, 1, 1, '', 40, 'Blk 1 Lot 1, Ilaya St.', 1, NULL, 'active'),
(32, 1, 4, '', 41, 'Blk 1 Lot 4, KAGOSHIMA', 1, NULL, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','officer','resident') NOT NULL DEFAULT 'resident',
  `contact_no` varchar(20) DEFAULT NULL,
  `account_status` varchar(20) NOT NULL DEFAULT 'approved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password`, `role`, `contact_no`, `account_status`) VALUES
(3, 'Admin', 'admin@gmail.com', '$2y$12$fg.swZRKoSN/1VCBEuYi7enalLl6eW7ZNbAL0Ue5YHYnJ6QILBr.O', 'admin', '09995670275', 'approved'),
(38, 'Mang Juan Tamad', 'allenedgarpurificacion@gmail.com', '$2y$12$iERRCnszwPFckI34X2amW.jXuVDjoWLnFXpJNPQoFZZ22ATxavu2q', 'resident', '09991318054', 'approved'),
(39, 'Ramon Julius Alday', 'julius.alday321@gmail.com', '$2y$10$/W5yC46hpL43sVY24mXNluIwBD/zSJd/W3dHp.6K6cc3d8Q0386S6', 'resident', '09853698399', 'approved'),
(40, 'Jian Mateo', 'mateocharls21@yahoo.com', '$2y$12$UhRzkakKFxytzY.qIoBdvugtyc8gKmbhQIaTAYk78hRX71HwKKTS.', 'resident', '09243515524', 'approved'),
(41, 'Ednel Arancillo', 'ednelarancillo@gmail.com', '$2y$12$pbcDvjp/P7dmZGL31AASEeSnO8vW046io/qWRK/q/cWGzSSXSaMTG', 'resident', '09992670575', 'approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`),
  ADD KEY `posted_by` (`posted_by`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_audit_created` (`created_at`),
  ADD KEY `idx_audit_user` (`user_id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`complaint_id`),
  ADD KEY `resident_id` (`resident_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`attempt_id`),
  ADD KEY `idx_attempt_email_time` (`email`,`attempted_at`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_notifications_user` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `resident_id` (`resident_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `resident_id` (`resident_id`),
  ADD KEY `idx_reservation_slot` (`facility`,`date_reserved`,`time_reserved`);

--
-- Indexes for table `residents`
--
ALTER TABLE `residents`
  ADD PRIMARY KEY (`resident_id`),
  ADD KEY `residents_ibfk_1` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `log_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `attempt_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `residents`
--
ALTER TABLE `residents`
  MODIFY `resident_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`posted_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`resident_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`resident_id`);

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`resident_id`);

--
-- Constraints for table `residents`
--
ALTER TABLE `residents`
  ADD CONSTRAINT `residents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
