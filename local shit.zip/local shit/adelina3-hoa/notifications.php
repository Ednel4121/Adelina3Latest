<?php
// Ipinapakita ang mga notification ng naka-login na user (hal. na-approve
// ang payment, reservation o complaint) at puwedeng i-mark lahat bilang read.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Notifications';
$userId = (int) $_SESSION['user_id'];
$error = '';
$message = $_SESSION['notification_message'] ?? '';
unset($_SESSION['notification_message']);

// Pinoprotektahan ng CSRF token ang form laban sa request na hindi galing sa page na ito.
$csrfToken = csrf_token();

// Tina-tanggap lamang ang valid na post request para i-mark lahat bilang read.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (isset($_POST['mark_all_read'])) {
        try {
            $readStmt = $conn->prepare(
                'UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0'
            );
            $readStmt->bind_param('i', $userId);
            $readStmt->execute();
            $_SESSION['notification_message'] = 'Na-mark na bilang read ang lahat ng notification.';
        } catch (mysqli_sql_exception $exception) {
            $error = 'Hindi ma-mark bilang read ang mga notification. Siguraduhing na-import na ang migration.sql.';
        }
        header('Location: notifications.php');
        exit;
    }
}

// Kapag pinindot ang "Buksan" sa isang notification, i-mark ito bilang read
// bago pumunta sa link nito, para hindi na kailangang pindutin pa ang
// "Mark all as read" pagbalik dito. Siguraduhing sa naka-login na user lang
// ang notification (notification_id + user_id).
if (isset($_GET['read'])) {
    $readId = filter_var($_GET['read'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $targetLink = 'notifications.php';
    if ($readId !== false) {
        try {
            $linkStmt = $conn->prepare(
                'SELECT link FROM notifications WHERE notification_id = ? AND user_id = ?'
            );
            $linkStmt->bind_param('ii', $readId, $userId);
            $linkStmt->execute();
            $linkRow = $linkStmt->get_result()->fetch_assoc();
            if ($linkRow) {
                $markStmt = $conn->prepare(
                    'UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?'
                );
                $markStmt->bind_param('ii', $readId, $userId);
                $markStmt->execute();
                $storedLink = trim((string) ($linkRow['link'] ?? ''));
                if ($storedLink !== '' && preg_match('/\A[a-z0-9_]+\.php\z/i', $storedLink)) {
                    $targetLink = $storedLink;
                }
            }
        } catch (mysqli_sql_exception $exception) {
            error_log('Notification mark read failed: ' . $exception->getMessage());
        }
    }
    header('Location: ' . $targetLink);
    exit;
}

// Kinukuha ang mga notification ng user, pinakabago muna.
$notifications = [];
$notificationsAvailable = true;
try {
    $listStmt = $conn->prepare(
        'SELECT notification_id, type, title, message, link, is_read, created_at
         FROM notifications
         WHERE user_id = ?
         ORDER BY created_at DESC
         LIMIT 50'
    );
    $listStmt->bind_param('i', $userId);
    $listStmt->execute();
    $result = $listStmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
} catch (mysqli_sql_exception $exception) {
    $notificationsAvailable = false;
}

$unreadTotal = 0;
foreach ($notifications as $notification) {
    if (empty($notification['is_read'])) {
        $unreadTotal++;
    }
}

require_once 'includes/header.php';
?>
  <section class="card">
    <div class="card-head">
      <div>
        <h2>Mga Notification</h2>
        <p class="muted">Dito mo makikita kung na-approve na ang payment, reservation o complaint mo.</p>
      </div>
      <?php if ($unreadTotal > 0): ?>
        <form action="notifications.php" method="post">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <button type="submit" name="mark_all_read" value="1" class="btn btn-small">Mark all as read (<?= (int) $unreadTotal ?>)</button>
        </form>
      <?php endif; ?>
    </div>
    <?php if ($error !== ''): ?>
      <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if ($message !== ''): ?>
      <p class="alert alert-success" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if (!$notificationsAvailable): ?>
      <p class="muted">Hindi pa naka-set up ang notifications. I-import muna ang migration.sql sa database.</p>
    <?php elseif (empty($notifications)): ?>
      <p class="muted">Wala ka pang notification.</p>
    <?php else: ?>
      <div class="notif-list">
        <?php foreach ($notifications as $notification): ?>
          <article class="notif-item<?= empty($notification['is_read']) ? ' unread' : '' ?>">
            <h3><?= htmlspecialchars($notification['title'], ENT_QUOTES, 'UTF-8') ?></h3>
            <p><?= nl2br(htmlspecialchars($notification['message'], ENT_QUOTES, 'UTF-8')) ?></p>
            <time class="notif-time"><?= htmlspecialchars(date('M d, Y h:i A', strtotime((string) $notification['created_at'])), ENT_QUOTES, 'UTF-8') ?></time>
            <?php if (!empty($notification['link']) && preg_match('/\A[a-z0-9_]+\.php\z/i', (string) $notification['link'])): ?>
              <a class="notif-link" href="notifications.php?read=<?= (int) $notification['notification_id'] ?>">Buksan &rarr;</a>
            <?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
<?php require_once 'includes/footer.php'; ?>
