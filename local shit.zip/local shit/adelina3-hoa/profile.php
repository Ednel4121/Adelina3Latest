<?php
// Ipinapakita ang profile ng naka-login na user at hinahayaang baguhin ang contact details.
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/validation.php';
require_once 'includes/send_mail.php';

$pageTitle = 'Profile';
$error = '';
$success = '';
$userId = (int) $_SESSION['user_id'];
$isResident = ($_SESSION['role'] ?? '') === 'resident';
$householdMembersInput = null;
$moveInDateInput = null;

$csrfToken = csrf_token();

// Ina-update ang resident details kasama ng contact info matapos i-validate ang lahat ng field.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $postedToken = $_POST['csrf_token'] ?? '';
    $currentPassword = post_string('current_password');
    $newPassword = post_string('new_password');
    $confirmPassword = post_string('confirm_password');

    if (!csrf_check($postedToken)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
        $error = 'Punan ang lahat ng password field.';
    } elseif (!isValidNewPassword($newPassword)) {
        $error = 'Ang bagong password ay dapat 12 hanggang 64 character.';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'Hindi magkatugma ang bagong password at confirmation.';
    } else {
        $passwordStmt = $conn->prepare('SELECT password FROM users WHERE user_id = ? LIMIT 1');
        $passwordStmt->bind_param('i', $userId);
        $passwordStmt->execute();
        $passwordRow = $passwordStmt->get_result()->fetch_assoc();
        $storedPassword = (string) ($passwordRow['password'] ?? '');
        $currentPasswordIsValid = $passwordRow && (
            password_verify($currentPassword, $storedPassword)
            || hash_equals($storedPassword, $currentPassword)
        );

        if (!$currentPasswordIsValid) {
            $error = 'Mali ang kasalukuyang password.';
        } else {
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $passwordUpdate = $conn->prepare('UPDATE users SET password = ? WHERE user_id = ?');
            $passwordUpdate->bind_param('si', $newPasswordHash, $userId);
            $passwordUpdate->execute();
            $success = 'Matagumpay na napalitan ang password.';

            // Abiso sa tunay na may-ari: kung may ibang taong nagbukas ng account at
            // nagpalit ng password, malalaman ito agad ng may-ari sa email.
            // Ang pagpalya ng email ay hindi pipigil sa pagpapalit ng password.
            try {
                $notifyStmt = $conn->prepare('SELECT full_name, email FROM users WHERE user_id = ? LIMIT 1');
                $notifyStmt->bind_param('i', $userId);
                $notifyStmt->execute();
                $notifyRow = $notifyStmt->get_result()->fetch_assoc();
                if ($notifyRow && filter_var($notifyRow['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                    sendPasswordChangedEmail($notifyRow['email'], (string) ($notifyRow['full_name'] ?? ''));
                }
            } catch (Throwable $notifyError) {
                error_log('Password change email failed for user ' . $userId . ': ' . $notifyError->getMessage());
            }
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = $_POST['csrf_token'] ?? '';
    $emailValue = post_string('email');
    $email = is_string($emailValue) ? trim($emailValue) : '';
    $contactNoValue = $_POST['contact_no'] ?? '';
    $contactNo = is_string($contactNoValue) ? trim($contactNoValue) : '';
    $householdValue = $_POST['household_members'] ?? '';
    $householdMembersInput = is_string($householdValue) ? trim($householdValue) : '';
    $householdMembers = is_string($householdValue)
        ? filter_var($householdMembersInput, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])
        : false;
    $moveInDateValue = $_POST['move_in_date'] ?? '';
    $moveInDateInput = is_string($moveInDateValue) ? trim($moveInDateValue) : '';
    $moveInDate = $moveInDateInput;
    $validMoveInDate = is_string($moveInDateValue) && $moveInDate === '';

    if ($moveInDate !== '') {
        $parsedMoveInDate = DateTime::createFromFormat('!Y-m-d', $moveInDate);
        $validMoveInDate = $parsedMoveInDate !== false
            && $parsedMoveInDate->format('Y-m-d') === $moveInDate;
    }

    if (!csrf_check($postedToken)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (!isValidPhilippineMobileNumber($contactNo)) {
        $error = 'Maglagay ng kapani-paniwalang 11-digit mobile number na nagsisimula sa 09.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Maglagay ng wastong email.';
    } elseif ($isResident && ($householdMembers === false || !$validMoveInDate)) {
        $error = 'Suriin ang bilang ng household members at move-in date.';
    } else {
        $transactionStarted = false;
        try {
            $conn->begin_transaction();
            $transactionStarted = true;

            if ($isResident) {
                $residentLookup = $conn->prepare('SELECT resident_id FROM residents WHERE user_id = ? FOR UPDATE');
                $residentLookup->bind_param('i', $userId);
                $residentLookup->execute();
                if (!$residentLookup->get_result()->fetch_assoc()) {
                    $conn->rollback();
                    $transactionStarted = false;
                    $error = 'Walang resident profile na maa-update sa account na ito.';
                } else {
                    $userUpdate = $conn->prepare('UPDATE users SET email = ?, contact_no = ? WHERE user_id = ?');
                    $userUpdate->bind_param('ssi', $email, $contactNo, $userId);
                    $userUpdate->execute();

                    $moveInDateForDb = $moveInDate === '' ? null : $moveInDate;
                    $residentUpdate = $conn->prepare(
                        'UPDATE residents SET household_members = ?, move_in_date = ? WHERE user_id = ?'
                    );
                    $residentUpdate->bind_param('isi', $householdMembers, $moveInDateForDb, $userId);
                    $residentUpdate->execute();

                    $conn->commit();
                    $transactionStarted = false;
                    $success = 'Matagumpay na na-update ang profile information.';
                }
            } else {
                $userUpdate = $conn->prepare('UPDATE users SET email = ?, contact_no = ? WHERE user_id = ?');
                $userUpdate->bind_param('ssi', $email, $contactNo, $userId);
                $userUpdate->execute();
                $conn->commit();
                $transactionStarted = false;
                $success = 'Matagumpay na na-update ang contact information.';
            }
        } catch (mysqli_sql_exception $exception) {
            if ($transactionStarted) {
                $conn->rollback();
            }
            if ($exception->getCode() === 1062) {
                $error = 'May account na gumagamit ng email na ito.';
            } else {
                error_log('Profile update failed: ' . $exception->getMessage());
                $error = 'Hindi na-update ang profile. Subukan muli.';
            }
        }
    }
}

// Pinagsasama ang user at resident details; maaaring walang resident record ang staff account.
$profileStmt = $conn->prepare(
    'SELECT u.full_name, u.email, u.contact_no, u.role,
            r.block_lot, r.household_members, r.move_in_date
     FROM users u
     LEFT JOIN residents r ON r.user_id = u.user_id
     WHERE u.user_id = ?'
);
$profileStmt->bind_param('i', $userId);
$profileStmt->execute();
$profile = $profileStmt->get_result()->fetch_assoc();

if (!$profile) {
    http_response_code(404);
    $error = 'Hindi makita ang profile ng account na ito.';
}

require_once 'includes/header.php';
?>
<div class="page-header"><h2>Profile</h2></div>
<?php if ($error !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($success !== ''): ?>
  <p class="alert alert-success" role="status"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($profile): ?>
  <section class="card profile-summary">
    <h3>Resident Profile</h3>
    <dl class="profile-details">
      <div><dt>Full Name</dt><dd><?= htmlspecialchars($profile['full_name'], ENT_QUOTES, 'UTF-8') ?></dd></div>
      <div><dt>Email</dt><dd><?= htmlspecialchars($profile['email'], ENT_QUOTES, 'UTF-8') ?></dd></div>
      <div><dt>Contact</dt><dd><?= htmlspecialchars($profile['contact_no'] ?? '', ENT_QUOTES, 'UTF-8') ?></dd></div>
      <?php if (($profile['role'] ?? '') !== 'admin'): ?>
        <div><dt>Block/Lot</dt><dd><?= htmlspecialchars($profile['block_lot'] ?? '', ENT_QUOTES, 'UTF-8') ?></dd></div>
        <div><dt>Household Members</dt><dd><?= htmlspecialchars((string) ($profile['household_members'] ?? ''), ENT_QUOTES, 'UTF-8') ?></dd></div>
        <div><dt>Move-in Date</dt><dd><?= htmlspecialchars($profile['move_in_date'] ?? '', ENT_QUOTES, 'UTF-8') ?></dd></div>
      <?php endif; ?>
      <div><dt>Role</dt><dd><?= htmlspecialchars(ucfirst($profile['role']), ENT_QUOTES, 'UTF-8') ?></dd></div>
    </dl>
  </section>
  <section class="card">
    <h3><?= $isResident ? 'Update Profile Information' : 'Update Contact Information' ?></h3>
    <form class="form-grid" action="profile.php" method="post">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
      <div class="form-field">
        <label for="profileContact">Contact</label>
        <input id="profileContact" type="tel" name="contact_no" data-validate-ph-mobile value="<?= htmlspecialchars($profile['contact_no'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="09XXXXXXXXX" minlength="11" maxlength="11" pattern="09[0-9]{9}" inputmode="numeric" autocomplete="tel" title="Kapani-paniwalang 11 digit na numero na nagsisimula sa 09" required>
      </div>
      <div class="form-field">
        <label for="profileEmail">Email</label>
        <input id="profileEmail" type="email" name="email" value="<?= htmlspecialchars($profile['email'], ENT_QUOTES, 'UTF-8') ?>" required>
      </div>
      <?php if ($isResident): ?>
        <div class="form-field">
          <label for="profileHouseholdMembers">Household Members</label>
          <input id="profileHouseholdMembers" type="number" name="household_members" min="1" value="<?= htmlspecialchars((string) ($householdMembersInput ?? $profile['household_members'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required>
        </div>
        <div class="form-field">
          <label for="profileMoveInDate">Move-in Date</label>
          <input id="profileMoveInDate" type="date" name="move_in_date" value="<?= htmlspecialchars((string) ($moveInDateInput ?? $profile['move_in_date'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </div>
      <?php endif; ?>
      <div class="form-actions"><button type="submit" class="btn btn-primary">Save Changes</button></div>
    </form>
  </section>
  <section class="card">
    <h3>Change Password</h3>
    <form class="form-grid" action="profile.php" method="post">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
      <div class="form-field">
        <label for="currentPassword">Current Password</label>
<div class="password-field">
        <input id="currentPassword" type="password" name="current_password" autocomplete="current-password" required>
        <button type="button" class="password-toggle" data-password-toggle="currentPassword" aria-label="Ipakita ang password" aria-pressed="false">
            <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          </button>
      </div>
      </div>
      <div class="form-field">
        <label for="newPassword">New Password</label>
<div class="password-field">
        <input id="newPassword" type="password" name="new_password" minlength="12" maxlength="64" autocomplete="new-password" required>
        <button type="button" class="password-toggle" data-password-toggle="newPassword" aria-label="Ipakita ang password" aria-pressed="false">
            <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          </button>
      </div>
        <small>Use 12 to 64 characters.</small>
      </div>
      <div class="form-field">
        <label for="confirmPassword">Confirm New Password</label>
<div class="password-field">
        <input id="confirmPassword" type="password" name="confirm_password" minlength="12" maxlength="64" autocomplete="new-password" required>
        <button type="button" class="password-toggle" data-password-toggle="confirmPassword" aria-label="Ipakita ang password" aria-pressed="false">
            <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          </button>
      </div>
      </div>
      <div class="form-actions"><button type="submit" name="change_password" value="1" class="btn btn-primary">Change Password</button></div>
    </form>
  </section>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
