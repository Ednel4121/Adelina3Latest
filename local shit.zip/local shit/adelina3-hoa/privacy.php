<?php
// Pampublikong pahina: Privacy Policy ng Adelina 3 HOA portal.
// Walang login na kailangan para mabasa ito. Kung naka-login na ang user,
// ipakita ang Dashboard button sa halip na Mag-login/Mag-register.
require_once 'includes/helpers.php';
start_secure_session();
$loggedIn = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Privacy Policy ng Adelina 3 Homeowners Association online portal.">
  <title>Privacy Policy | Adelina 3 Homeowners Association</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/style.css') ?>">
  <link rel="stylesheet" href="assets/css/redesign.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/redesign.css') ?>">
</head>
<body id="top" class="legal-page">
  <header class="legal-header">
    <a class="legal-brand" href="landing.php" aria-label="Adelina 3 Homeowners Association - Home">
      <img src="assets/images/logo.png?v=<?= (int) filemtime(__DIR__ . '/assets/images/logo.png') ?>" alt="Adelina 3 Homeowners Association logo">
    </a>
  </header>

  <main class="legal-wrap">
    <article class="legal-card">
      <?php if (!$loggedIn): ?>
        <a class="login-home-link" href="landing.php"><span aria-hidden="true">&larr;</span> <span data-i18n="legal.back">Bumalik sa landing page</span></a>
      <?php endif; ?>
      <h1>Privacy Policy</h1>
      <p class="muted" data-i18n="priv.updated">Huling update: Nobyembre 22, 2026</p>

      <h2 data-i18n="priv.s1h">1. Panimula</h2>
      <p data-i18n="priv.s1p">Ang online portal na ito ay pinapatakbo ng <strong>Adelina 3 Homeowners Association</strong> para sa mga residente ng Adelina 3. Ipinapaliwanag ng patakarang ito kung anong impormasyon ang kinokolekta namin, paano namin ito ginagamit, at ano ang iyong mga karapatan. Sumusunod ang patakarang ito sa <strong>Data Privacy Act of 2012 (Republic Act No. 10173)</strong> ng Pilipinas.</p>

      <h2 data-i18n="priv.s2h">2. Anong impormasyon ang kinokolekta namin</h2>
      <p data-i18n="priv.s2p">Kinokolekta lang namin ang impormasyong kailangan para patakbuhin ang HOA portal:</p>
      <ul>
        <li data-i18n="priv.s2l1"><strong>Account:</strong> buong pangalan, email address, contact number, at Block &amp; Lot.</li>
        <li data-i18n="priv.s2l2"><strong>Dues at payments:</strong> payment records, halaga, paraan ng pagbabayad, reference, at proof of payment.</li>
        <li data-i18n="priv.s2l3"><strong>Complaints:</strong> paksa, detalye, attachment, at tugon ng HOA officer.</li>
        <li data-i18n="priv.s2l4"><strong>Reservations:</strong> pasilidad, petsa, oras, at layunin ng reservation.</li>
        <li data-i18n="priv.s2l5"><strong>Login records:</strong> bilang ng maling pag-login (para sa seguridad ng account).</li>
      </ul>

      <h2 data-i18n="priv.s3h">3. Paano namin ginagamit ang impormasyon</h2>
      <p data-i18n="priv.s3p">Ginagamit namin ang iyong impormasyon para:</p>
      <ul>
        <li data-i18n="priv.s3l1">Pamahalaan ang mga residente at ang kanilang account;</li>
        <li data-i18n="priv.s3l2">Subaybayan ang dues at i-validate ang mga bayad;</li>
        <li data-i18n="priv.s3l3">Mag-post ng mga anunsyo para sa komunidad;</li>
        <li data-i18n="priv.s3l4">Tanggapin at tugunan ang mga complaint;</li>
        <li data-i18n="priv.s3l5">Pamahalaan ang mga reservation ng pasilidad; at</li>
        <li data-i18n="priv.s3l6">Panatilihing ligtas ang portal laban sa maling paggamit.</li>
      </ul>
      <p data-i18n="priv.s3p2">Hindi namin ibinebenta, inuupahan, o ibinabahagi ang iyong personal na impormasyon sa sinumang nasa labas ng HOA.</p>

      <h2 data-i18n="priv.s4h">4. Legal na batayan</h2>
      <p data-i18n="priv.s4p">Ang pagproseso ng iyong impormasyon ay nakabatay sa iyong <strong>pahintulot</strong> nang mag-register ka, at sa lehitimong pangangailangan ng HOA na pamahalaan ang komunidad. Maaari mong bawiin ang iyong pahintulot anumang oras sa pamamagitan ng paghingi ng pagbura ng iyong account (tingnan ang Seksyon 8).</p>

      <h2 data-i18n="priv.s5h">5. Paano namin pinoprotektahan ang iyong datos</h2>
      <ul>
        <li data-i18n="priv.s5l1">Ang mga password ay naka-hash (bcrypt) at hindi kailanman iniimbak bilang plain text.</li>
        <li data-i18n="priv.s5l2">Ang bawat residente ay makikita lang ang sarili niyang records.</li>
        <li data-i18n="priv.s5l3">Ang admin at HOA officer lang ang may access sa lahat ng records, at kailangan ito para sa kanilang tungkulin.</li>
        <li data-i18n="priv.s5l4">Ang mga pag-login ay may limitasyon laban sa paulit-ulit na maling password.</li>
      </ul>

      <h2 data-i18n="priv.s6h">6. Gaano katagal namin itinatago ang iyong datos</h2>
      <p data-i18n="priv.s6p">Itinatago namin ang iyong impormasyon habang residente ka ng Adelina 3 at may account ka sa portal. Kapag binura ang iyong account, binubura rin ang kaugnay na records (resident profile, payments, complaints, at reservations) ayon sa patakaran ng HOA.</p>

      <h2 data-i18n="priv.s7h">7. Cookies</h2>
      <p data-i18n="priv.s7p">Gumagamit ang portal ng isang <strong>session cookie</strong> na kailangan para manatili kang naka-login habang ginagamit mo ang site. Ito ay isang essential cookie at hindi ito maaaring i-off kung gusto mong mag-login. <strong>Walang third-party tracking cookies</strong> (tulad ng analytics o advertising) ang portal. Maaari mong tanggapin o tanggihan ang mga non-essential cookie sa pamamagitan ng cookie banner na lumalabas sa ibaba ng pahina.</p>

      <h2 data-i18n="priv.s8h">8. Ang iyong mga karapatan</h2>
      <p data-i18n="priv.s8p">Ayon sa Data Privacy Act of 2012, may karapatan ka na:</p>
      <ul>
        <li data-i18n="priv.s8l1">Malaman kung anong impormasyon ang kinokolekta namin tungkol sa iyo;</li>
        <li data-i18n="priv.s8l2">Makakuha ng kopya ng iyong impormasyon;</li>
        <li data-i18n="priv.s8l3">Humingi ng pagwawasto kung may mali sa iyong datos;</li>
        <li data-i18n="priv.s8l4">Humingi ng pagbura ng iyong account at datos;</li>
        <li data-i18n="priv.s8l5">Bawiin ang iyong pahintulot; at</li>
        <li data-i18n="priv.s8l6">Magreklamo sa National Privacy Commission kung sa tingin mo ay may paglabag.</li>
      </ul>
      <p data-i18n="priv.s8p2">Para humiling ng pagwawasto o pagbura, makipag-ugnayan sa HOA admin sa pamamagitan ng portal (mag-file ng complaint o kausapin ang admin). Maaaring burahin ng admin ang iyong account kasama ang lahat ng kaugnay na records.</p>

      <h2 data-i18n="priv.s9h">9. Pagbabago sa patakarang ito</h2>
      <p data-i18n="priv.s9p">Maaari naming baguhin ang patakarang ito paminsan-minsan. Ang pinakabagong bersyon ay palaging makikita sa pahinang ito, kasama ang petsa ng huling update.</p>

      <h2 data-i18n="priv.s10h">10. Makipag-ugnayan</h2>
      <p data-i18n="priv.s10p">Kung may tanong ka tungkol sa patakarang ito o sa iyong datos, makipag-ugnayan sa HOA admin sa pamamagitan ng portal.</p>
      <div class="legal-actions">
        <?php if ($loggedIn): ?>
          <a class="btn btn-primary" href="dashboard.php">Back to dashboard</a>
        <?php else: ?>
          <a class="btn landing-login" href="login.php" data-i18n="nav.login">Mag-login</a>
          <a class="btn btn-primary" href="register.php" data-i18n="nav.register">Mag-register</a>
        <?php endif; ?>
      </div>
    </article>
  </main>

  <footer class="landing-footer">
    <span>
      <a href="privacy.php">Privacy Policy</a>
      &middot;
      <a href="terms.php">Terms &amp; Conditions</a>
    </span>
    <span>&copy; <?= date('Y') ?> Adelina 3 HOA</span>
  </footer>
  <a class="back-to-top" href="#top" aria-label="Bumalik sa itaas">
    <span aria-hidden="true">&uarr;</span> Bumalik sa taas
  </a>
</body>
</html>
