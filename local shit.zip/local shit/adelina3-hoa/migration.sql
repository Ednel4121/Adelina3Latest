-- Migration para sa Adelina 3 HOA wishlist build (2026-11-22).
-- I-import ito sa phpMyAdmin (live DB muna, tapos local XAMPP DB) BAGO i-upload ang mga bagong PHP file.
-- Tandaan: kung mag-error ng "Duplicate column name" o "Table already exists" sa pag-import,
-- ibig sabihin ay nailapat na ang bahaging iyon dati at ligtas lang itong balewalain.

-- Notifications table para sa resident notification system.
-- I-import ito sa phpMyAdmin (live DB muna, tapos local XAMPP DB).
-- Pagkatapos nito, makakatanggap na ng notification ang resident kapag
-- na-approve o na-reject ang payment, reservation, o na-update ang complaint.
CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    type VARCHAR(30) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    link VARCHAR(255) NOT NULL DEFAULT '',
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (notification_id),
    INDEX idx_notifications_user (user_id, is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Kategorya para sa announcements (General, Emergency, Events, Maintenance, Reminder).
-- I-import ito sa phpMyAdmin (live DB muna, tapos local XAMPP DB) BAGO i-upload ang bagong announcements.php.
-- Ang mga lumang announcement ay awtomatikong magiging 'General' dahil sa DEFAULT.
-- Tandaan: kung mag-error ng "Duplicate column name" sa pag-import, ibig sabihin ay nailapat na ito dati at ligtas lang itong balewalain.
ALTER TABLE announcements ADD COLUMN category VARCHAR(30) NOT NULL DEFAULT 'General';
