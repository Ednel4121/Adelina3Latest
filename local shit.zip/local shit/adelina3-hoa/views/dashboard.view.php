<?php
// View lang ito: HTML na may simpleng echo at loop. Ang logic at query ay nasa dashboard.php.
?>
<?php if (!$isStaff): ?>
  <section class="welcome">
    <h2>Maligayang pagdating, <?= htmlspecialchars(trim((string) ($_SESSION['full_name'] ?? 'Resident')), ENT_QUOTES, 'UTF-8') ?>!</h2>
    <p>Malayang tingnan ang iyong account at mga serbisyo ng HOA.</p>
  </section>

  <div class="stat-strip">
    <?php
    $resLinks = ['payments.php', 'complaints.php', 'reservations.php', 'announcements.php'];
    $resSubtitles = ['Pending balance', 'Active concerns', 'Booked facilities', 'Community updates'];

    foreach ($stats as $index => [$label, $value]):
    ?>
      <a href="<?= $resLinks[$index] ?? '#' ?>" class="stat-cell">
        <span class="stat-label"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></span>
        <span class="stat-value"><?= htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8') ?></span>
        <span class="stat-note"><?= $resSubtitles[$index] ?? '' ?></span>
      </a>
    <?php endforeach; ?>
  </div>

  <section aria-label="Mga chart">
    <div class="dash-grid">
      <!-- Kasaysayan ng Bayad -->
      <div class="panel">
        <div class="panel-head">
          <div>
            <h3 class="panel-title">Kasaysayan ng Bayad</h3>
            <p class="panel-sub">Kabuuang bayad bawat buwan (huling 6 na buwan)</p>
          </div>
        </div>
        <div class="panel-body">
          <?php if (count($paymentChartRows) === 0): ?>
            <div class="empty">
              <p class="empty-title">Wala pang datos ng bayad.</p>
              <p class="empty-text">Ang iyong kasaysayan ng bayad ay lalabas dito kapag may naitalang transaksyon.</p>
            </div>
          <?php else: ?>
            <?php foreach ($paymentChartRows as $paymentRow): ?>
              <div class="meter">
                <div class="meter-top">
                  <span class="meter-label"><?= htmlspecialchars($paymentRow['label'], ENT_QUOTES, 'UTF-8') ?></span>
                  <span class="meter-figure">₱<?= number_format((float) $paymentRow['kabuuan'], 2) ?></span>
                </div>
                <div class="meter-track"><div class="meter-fill" style="width: <?= (float) $paymentRow['pct'] ?>%;"></div></div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- Katayuan ng mga Reklamo -->
      <div class="panel">
        <div class="panel-head">
          <div>
            <h3 class="panel-title">Katayuan ng mga Reklamo</h3>
            <p class="panel-sub">Bilang ng iyong reklamo ayon sa katayuan</p>
          </div>
        </div>
        <div class="panel-body">
          <?php if ($complaintChartTotal === 0): ?>
            <div class="empty">
              <p class="empty-title">Wala pang reklamo.</p>
              <p class="empty-text">Lahat ng iyong isinumiteng reklamo ay ipapakita rito.</p>
            </div>
          <?php else: ?>
            <?php $dotColors = ['#d19a1f', '#3a84b8', '#1f8f6a']; ?>
            <?php foreach ($complaintChartRows as $idx => $complaintRow):
              $color = $dotColors[$idx] ?? '#147d68';
            ?>
              <div class="meter">
                <div class="meter-top">
                  <span class="meter-label">
                    <span class="swatch" style="background-color: <?= $color ?>;"></span>
                    <?= htmlspecialchars($complaintRow['label'], ENT_QUOTES, 'UTF-8') ?>
                  </span>
                  <span class="meter-figure"><?= (int) $complaintRow['bilang'] ?> (<?= number_format((float) $complaintRow['pct'], 1) ?>%)</span>
                </div>
                <div class="meter-track"><div class="meter-fill" style="width: <?= (float) $complaintRow['pct'] ?>%; background-color: <?= $color ?>;"></div></div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- Mabilisang link -->
  <div class="action-row">
    <?php
    $actions = [
        ['payments.php', 'Bayarin', 'View Payments'],
        ['reservations.php', 'Facilities', 'Make Reservation'],
        ['complaints.php', 'Concerns', 'Submit Complaint'],
        ['profile.php', 'Account', 'Manage Profile'],
    ];
    foreach ($actions as [$href, $sub, $title]): ?>
      <a href="<?= $href ?>" class="action-link">
        <small><?= $sub ?></small>
        <strong><?= $title ?></strong>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Pinakabagong Announcements -->
  <section class="panel">
    <div class="panel-head">
      <h3 class="panel-title">Pinakabagong Announcements</h3>
      <a href="announcements.php" class="panel-link">Tingnan Lahat</a>
    </div>

    <?php if (empty($announcementRows)): ?>
      <div class="empty">
        <p class="empty-title">Wala pang announcements.</p>
      </div>
    <?php else: ?>
      <ul class="bulletin">
        <?php foreach ($announcementRows as $a): ?>
          <li class="bulletin-item">
            <h4 class="bulletin-title"><?= htmlspecialchars($a['title'], ENT_QUOTES, 'UTF-8') ?></h4>
            <p class="bulletin-body"><?= nl2br(htmlspecialchars($a['body'], ENT_QUOTES, 'UTF-8')) ?></p>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>

<?php else: ?>
  <div class="page-header"><h2>Dashboard</h2></div>

  <div class="stat-strip">
    <?php
    $links = ['residents.php', 'payments.php', 'complaints.php', 'reservations.php'];
    $subtitles = ['Registered members', 'Pending collection', 'Needs resolution', 'Scheduled events'];

    foreach ($stats as $index => [$label, $value]):
    ?>
      <a href="<?= $links[$index] ?? '#' ?>" class="stat-cell">
        <span class="stat-label"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></span>
        <span class="stat-value"><?= htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8') ?></span>
        <span class="stat-note"><?= $subtitles[$index] ?? '' ?></span>
      </a>
    <?php endforeach; ?>
  </div>

  <section aria-label="Mga chart">
    <div class="dash-grid">
      <!-- Kasaysayan ng Bayad -->
      <div class="panel">
        <div class="panel-head">
          <div>
            <h3 class="panel-title">Kasaysayan ng Bayad</h3>
            <p class="panel-sub">Kabuuang bayad bawat buwan (huling 6 na buwan)</p>
          </div>
        </div>
        <div class="panel-body">
          <?php if (count($paymentChartRows) === 0): ?>
            <div class="empty">
              <p class="empty-title">Wala pang datos ng bayad.</p>
              <p class="empty-text">Ang kasaysayan ng bayad ay lalabas dito kapag may naitalang transaksyon.</p>
            </div>
          <?php else: ?>
            <?php foreach ($paymentChartRows as $paymentRow): ?>
              <div class="meter">
                <div class="meter-top">
                  <span class="meter-label"><?= htmlspecialchars($paymentRow['label'], ENT_QUOTES, 'UTF-8') ?></span>
                  <span class="meter-figure">₱<?= number_format((float) $paymentRow['kabuuan'], 2) ?></span>
                </div>
                <div class="meter-track"><div class="meter-fill" style="width: <?= (float) $paymentRow['pct'] ?>%;"></div></div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- Katayuan ng mga Reklamo -->
      <div class="panel">
        <div class="panel-head">
          <div>
            <h3 class="panel-title">Katayuan ng mga Reklamo</h3>
            <p class="panel-sub">Bilang ng reklamo ayon sa katayuan</p>
          </div>
        </div>
        <div class="panel-body">
          <?php if ($complaintChartTotal === 0): ?>
            <div class="empty">
              <p class="empty-title">Wala pang reklamo.</p>
            </div>
          <?php else: ?>
            <?php $dotColors = ['#d19a1f', '#3a84b8', '#1f8f6a']; ?>
            <?php foreach ($complaintChartRows as $idx => $complaintRow):
              $color = $dotColors[$idx] ?? '#147d68';
            ?>
              <div class="meter">
                <div class="meter-top">
                  <span class="meter-label">
                    <span class="swatch" style="background-color: <?= $color ?>;"></span>
                    <?= htmlspecialchars($complaintRow['label'], ENT_QUOTES, 'UTF-8') ?>
                  </span>
                  <span class="meter-figure"><?= (int) $complaintRow['bilang'] ?> (<?= number_format((float) $complaintRow['pct'], 1) ?>%)</span>
                </div>
                <div class="meter-track"><div class="meter-fill" style="width: <?= (float) $complaintRow['pct'] ?>%; background-color: <?= $color ?>;"></div></div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <section class="panel">
    <div class="panel-head">
      <div>
        <h3 class="panel-title">Pinakabagong Announcements</h3>
        <p class="panel-sub">Mga kamakailang abiso para sa komunidad</p>
      </div>
      <a href="announcements.php" class="panel-link">Tingnan Lahat</a>
    </div>

    <?php if (count($announcementRows) === 0): ?>
      <div class="empty">
        <p class="empty-title">Wala pang announcements.</p>
      </div>
    <?php else: ?>
      <ul class="bulletin">
        <?php foreach ($announcementRows as $announcement): ?>
          <li class="bulletin-item">
            <h4 class="bulletin-title"><?= htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8') ?></h4>
            <p class="bulletin-body"><?= nl2br(htmlspecialchars($announcement['body'], ENT_QUOTES, 'UTF-8')) ?></p>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>

<?php endif; ?>
