<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';

$announcementId = filter_var(
    $_GET['id'] ?? null,
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1]]
);

if ($announcementId === false) {
    http_response_code(404);
    exit;
}

$stmt = $conn->prepare('SELECT image_file, image_data, image_mime FROM announcements WHERE announcement_id = ?');
$stmt->bind_param('i', $announcementId);
$stmt->execute();
$announcement = $stmt->get_result()->fetch_assoc();
$imageFile = $announcement['image_file'] ?? '';

if (!preg_match('/\A[a-f0-9]{32}\.(?:jpg|png|gif|webp)\z/i', $imageFile)) {
    http_response_code(404);
    exit;
}

// Nasa database na ang image ng mga bagong upload; ang lumang file
// sa folder pa rin ang gagamitin kapag walang naka-save na bytes.
$imageData = $announcement['image_data'] ?? null;
$imageMime = $announcement['image_mime'] ?? null;

if ($imageData !== null) {
    $imageTypes = [
        'jpg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp',
    ];
    $extension = strtolower(pathinfo($imageFile, PATHINFO_EXTENSION));
    $mimeType = is_string($imageMime) && isset($imageTypes[$extension]) && $imageMime === $imageTypes[$extension]
        ? $imageMime
        : ($imageTypes[$extension] ?? 'application/octet-stream');

    header('Content-Type: ' . $mimeType);
    header('Content-Length: ' . (string) strlen($imageData));
    header('Content-Disposition: inline; filename="announcement-image.' . $extension . '"');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, max-age=3600');
    echo $imageData;
    exit;
}

$imagePath = dirname(__DIR__, 2)
    . DIRECTORY_SEPARATOR . 'hoa-announcement-images'
    . DIRECTORY_SEPARATOR . $imageFile;

if (!is_file($imagePath) || !is_readable($imagePath)) {
    http_response_code(404);
    exit;
}

$imageTypes = [
    'jpg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    'webp' => 'image/webp',
];
$extension = strtolower(pathinfo($imageFile, PATHINFO_EXTENSION));

header('Content-Type: ' . $imageTypes[$extension]);
header('Content-Length: ' . (string) filesize($imagePath));
header('Content-Disposition: inline; filename="announcement-image.' . $extension . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=3600');
readfile($imagePath);
exit;
