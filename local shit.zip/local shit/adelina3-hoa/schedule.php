<?php
// Ipinapakita ng page na ito ang iskedyul ng isang facility sa isang petsa
// para makita ng resident kung okupado na ang isang oras bago mag-reserve.
// Sadyang simple ang page na ito (walang maraming kahon) para madaling
// basahin sa cellphone, lalo na ng mga nakatatanda.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Schedule of Facility';
$facilities = ['Clubhouse', 'Basketball Court', 'Park Area'];

// Facility mula sa URL; kapag wala o hindi wasto, unang facility ang default.
$facility = trim((string) ($_GET['facility'] ?? ''));
if (!in_array($facility, $facilities, true)) {
    $facility = $facilities[0];
}

// Petsa mula sa URL; kapag wala o hindi wasto, ngayong araw ang default.
$dateParam = trim((string) ($_GET['date_reserved'] ?? ''));
$parsedDate = DateTime::createFromFormat('!Y-m-d', $dateParam);
$scheduleDate = ($parsedDate !== false && $parsedDate->format('Y-m-d') === $dateParam)
    ? $dateParam
    : date('Y-m-d');

// Nakaraan at susunod na araw para sa mabilis na paglipat ng petsa.
$prevDate = date('Y-m-d', strtotime($scheduleDate . ' -1 day'));
$nextDate = date('Y-m-d', strtotime($scheduleDate . ' +1 day'));

// Lahat ng reservation ng facility sa petsang ito, kasama ang pangalan
// ng nag-reserve (kapareho ng ipinapakita sa reservations.php).
$scheduleStmt = $conn->prepare(
    'SELECT b.time_reserved, b.time_to, b.purpose, b.status, u.full_name
     FROM reservations b
     JOIN residents r ON b.resident_id = r.resident_id
     JOIN users u ON r.user_id = u.user_id
     WHERE b.facility = ? AND b.date_reserved = ?
     ORDER BY b.time_reserved ASC, b.reservation_id ASC'
);
$scheduleStmt->bind_param('ss', $facility, $scheduleDate);
$scheduleStmt->execute();
$dayReservations = $scheduleStmt->get_result();

// Approved at Pending lang ang kumukuha ng slot; ang Not Approved ay libre pa rin.
$occupying = [];
$notApprovedCount = 0;
while ($row = $dayReservations->fetch_assoc()) {
    if ($row['status'] === 'Approved' || $row['status'] === 'Pending') {
        $occupying[] = $row;
    } else {
        $notApprovedCount++;
    }
}

require_once 'includes/header.php';
?>
<div class="page-header"><h2>Schedule of Facility</h2></div>
<p class="muted">Check whether a facility is already reserved before booking.</p>

<section class="card schedule-filter">
  <form class="form-grid" action="schedule.php" method="get">
    <div class="form-field">
      <label for="scheduleFacility">Facility</label>
      <select id="scheduleFacility" name="facility" required>
        <?php foreach ($facilities as $option): ?>
          <option value="<?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?>"<?= $facility === $option ? ' selected' : '' ?>><?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-field">
      <label for="scheduleDate">Date</label>
      <input id="scheduleDate" type="date" name="date_reserved" value="<?= htmlspecialchars($scheduleDate, ENT_QUOTES, 'UTF-8') ?>" required>
    </div>
    <div class="form-actions"><button type="submit" class="btn btn-primary">View Schedule</button></div>
  </form>
  <div class="schedule-nav">
    <a href="schedule.php?facility=<?= urlencode($facility) ?>&amp;date_reserved=<?= htmlspecialchars($prevDate, ENT_QUOTES, 'UTF-8') ?>">&larr; Previous Day</a>
    <span><?= htmlspecialchars(date('M d, Y', strtotime($scheduleDate)), ENT_QUOTES, 'UTF-8') ?></span>
    <a href="schedule.php?facility=<?= urlencode($facility) ?>&amp;date_reserved=<?= htmlspecialchars($nextDate, ENT_QUOTES, 'UTF-8') ?>">Next Day &rarr;</a>
  </div>
</section>

<section class="card">
  <div class="card-head">
    <h3><?= htmlspecialchars($facility, ENT_QUOTES, 'UTF-8') ?> — <?= htmlspecialchars(date('M d, Y', strtotime($scheduleDate)), ENT_QUOTES, 'UTF-8') ?></h3>
  </div>
  <?php if (count($occupying) === 0): ?>
    <p class="schedule-free">No reservations for this date. The facility is available all day.</p>
  <?php else: ?>
    <p class="schedule-free">These times are reserved. All other times are available.</p>
    <ul class="schedule-list">
      <?php foreach ($occupying as $reservation): ?>
        <li>
          <strong>
            <?= !empty($reservation['time_reserved']) ? htmlspecialchars(date('g:i A', strtotime($reservation['time_reserved'])), ENT_QUOTES, 'UTF-8') : '—' ?>
            <?php if (!empty($reservation['time_to'])): ?>
              - <?= htmlspecialchars(date('g:i A', strtotime($reservation['time_to'])), ENT_QUOTES, 'UTF-8') ?>
            <?php endif; ?>
          </strong>
          &nbsp;<?= htmlspecialchars($reservation['full_name'], ENT_QUOTES, 'UTF-8') ?>
          <span class="muted"><?= htmlspecialchars($reservation['purpose'] ?? '', ENT_QUOTES, 'UTF-8') ?> &middot; <?= htmlspecialchars($reservation['status'], ENT_QUOTES, 'UTF-8') ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
  <?php if ($notApprovedCount > 0): ?>
    <p class="muted"><?= $notApprovedCount ?> reservation(s) were not approved for this date; those time slots remain available.</p>
  <?php endif; ?>
  <div class="form-actions schedule-actions">
    <a class="btn btn-primary" href="reservations.php">Make Reservation</a>
  </div>
</section>
<?php require_once 'includes/footer.php'; ?>
