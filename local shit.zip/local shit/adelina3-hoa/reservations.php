<?php
// Pinapahintulutan ang resident na mag-request ng facility at ang staff na mag-approve o tumanggi.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Reservations';
$role = $_SESSION['role'] ?? 'resident';
$isResident = $role === 'resident';
$isAdmin = $role === 'admin';
$isStaff = in_array($role, ['admin', 'officer'], true);
$userId = (int) $_SESSION['user_id'];
$actorName = trim((string) ($_SESSION['full_name'] ?? ''));
$error = '';
$message = $_SESSION['reservation_message'] ?? '';
unset($_SESSION['reservation_message']);

$csrfToken = csrf_token();
$facilities = ['Clubhouse', 'Basketball Court', 'Park Area'];
$hours = range(1, 12);
$periods = ['AM', 'PM'];
$facility = '';
$reservationDate = '';
$reservationFromHour = '';
$reservationFromMinute = '';
$reservationFromPeriod = 'AM';
$reservationToHour = '';
$reservationToMinute = '';
$reservationToPeriod = 'AM';
$purpose = '';
$residentId = 0;

// Iniuugnay ang reservation sa resident profile ng kasalukuyang account.
if ($isResident) {
    $residentStmt = $conn->prepare('SELECT resident_id FROM residents WHERE user_id = ? LIMIT 1');
    $residentStmt->bind_param('i', $userId);
    $residentStmt->execute();
    $resident = $residentStmt->get_result()->fetch_assoc();
    if ($resident) {
        $residentId = (int) $resident['resident_id'];
    }
}

// Pinoproseso ang bagong reservation o staff decision pagkatapos beripikahin ang token at role.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (isset($_POST['create_reservation']) && $isResident) {
        $facility = trim(post_string('facility'));
        $reservationDate = trim(post_string('date_reserved'));
        $reservationFromHour = trim(post_string('time_from_hour'));
        $reservationFromMinute = trim(post_string('time_from_minute'));
        $reservationFromPeriod = trim(post_string('time_from_period'));
        $reservationToHour = trim(post_string('time_to_hour'));
        $reservationToMinute = trim(post_string('time_to_minute'));
        $reservationToPeriod = trim(post_string('time_to_period'));
        $purpose = trim(post_string('purpose'));
        $parsedDate = DateTime::createFromFormat('!Y-m-d', $reservationDate);
        $validDate = $parsedDate !== false && $parsedDate->format('Y-m-d') === $reservationDate;
        $validFromMinute = preg_match('/\A[0-9]{1,2}\z/', $reservationFromMinute) === 1
            && (int) $reservationFromMinute <= 59;
        $validToMinute = preg_match('/\A[0-9]{1,2}\z/', $reservationToMinute) === 1
            && (int) $reservationToMinute <= 59;
        $validFromTime = in_array($reservationFromHour, array_map('strval', $hours), true)
            && $validFromMinute
            && in_array($reservationFromPeriod, $periods, true);
        $validToTime = in_array($reservationToHour, array_map('strval', $hours), true)
            && $validToMinute
            && in_array($reservationToPeriod, $periods, true);

        $timeFromValue = '';
        if ($validFromTime) {
            $minuteForTime = str_pad((string) (int) $reservationFromMinute, 2, '0', STR_PAD_LEFT);
            $parsedTime = DateTime::createFromFormat(
                '!g:i A',
                $reservationFromHour . ':' . $minuteForTime . ' ' . $reservationFromPeriod
            );
            $timeFromValue = $parsedTime !== false ? $parsedTime->format('H:i:s') : '';
        }
        $timeToValue = '';
        if ($validToTime) {
            $minuteForTime = str_pad((string) (int) $reservationToMinute, 2, '0', STR_PAD_LEFT);
            $parsedTime = DateTime::createFromFormat(
                '!g:i A',
                $reservationToHour . ':' . $minuteForTime . ' ' . $reservationToPeriod
            );
            $timeToValue = $parsedTime !== false ? $parsedTime->format('H:i:s') : '';
        }
        $pastTimeToday = $reservationDate === date('Y-m-d')
            && $timeFromValue !== '' && $timeFromValue < date('H:i:s');

        if ($residentId < 1) {
            $error = 'Wala pang resident profile na naka-link sa account mo.';
        } elseif (
            !in_array($facility, $facilities, true)
            || !$validDate
            || $reservationDate < date('Y-m-d')
            || $pastTimeToday
            || !$validFromTime
            || !$validToTime
            || $timeToValue <= $timeFromValue
            || $purpose === ''
            || mb_strlen($purpose) > 150
        ) {
            $error = 'Suriin ang facility, future date, From/To time (dapat mas huli ang To), at purpose (hanggang 150 character).';
        } else {
            // Ang mga oras ay nakompute na sa itaas (12-oras na oras
            // papuntang format na ginagamit ng database).

            // Naka-transaction ang check at insert para hindi makalusot ang
            // sabay na booking sa iisang slot.
            $conn->begin_transaction();
            try {
                // Bawal ang double booking: parehong facility, petsa at oras na
                // may Pending o Approved na reservation na.
                $conflictStmt = $conn->prepare(
                    "SELECT reservation_id FROM reservations
                     WHERE facility = ? AND date_reserved = ?
                       AND time_reserved < ?
                       AND COALESCE(time_to, ADDTIME(time_reserved, '00:00:01')) > ?
                       AND status <> 'Not Approved' LIMIT 1 FOR UPDATE"
                );
                $conflictStmt->bind_param('ssss', $facility, $reservationDate, $timeToValue, $timeFromValue);
                $conflictStmt->execute();
                if ($conflictStmt->get_result()->fetch_assoc()) {
                    $conn->rollback();
                    $error = 'May naka-reserve na sa facility sa oras na ito. Pumili ng ibang oras.';
                } else {
                    $stmt = $conn->prepare(
                        "INSERT INTO reservations (resident_id, facility, date_reserved, time_reserved, time_to, purpose, status)
                         VALUES (?, ?, ?, ?, ?, ?, 'Pending')"
                    );
                    $stmt->bind_param('isssss', $residentId, $facility, $reservationDate, $timeFromValue, $timeToValue, $purpose);
                    $stmt->execute();
                    $conn->commit();

                    // Ipaalam sa admin/officer na may bagong reservation ang resident.
                    notifyStaff(
                        $conn,
                        'reservation',
                        'Bagong reservation',
                        ($actorName !== '' ? $actorName . ' — ' : '') . $facility . ', ' . date('M d, Y', strtotime($reservationDate)) . ' ' . date('g:i A', strtotime($timeFromValue)) . ' - ' . date('g:i A', strtotime($timeToValue)),
                        'reservations.php'
                    );

                    $_SESSION['reservation_message'] = 'Matagumpay na naipasa ang reservation. Pending pa ito para sa approval.';
                    header('Location: reservations.php');
                    exit;
                }
            } catch (mysqli_sql_exception $exception) {
                $conn->rollback();
                error_log('Reservation failed: ' . $exception->getMessage());
                $error = 'Hindi naipasa ang reservation. Subukan muli.';
            }
        }
    } elseif (isset($_POST['delete_reservation']) && $isAdmin) {
        $reservationId = filter_var(
            $_POST['reservation_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        if ($reservationId === false) {
            $error = 'Hindi wasto ang reservation na pinili.';
        } else {
            $deleteStmt = $conn->prepare('DELETE FROM reservations WHERE reservation_id = ?');
            $deleteStmt->bind_param('i', $reservationId);
            $deleteStmt->execute();
            if ($deleteStmt->affected_rows > 0) {
                logAudit($conn, $userId, 'delete_reservation', 'Binura ang reservation (reservation_id=' . $reservationId . ').');
            }
            $_SESSION['reservation_message'] = $deleteStmt->affected_rows > 0
                ? 'Matagumpay na nabura ang reservation.'
                : 'Hindi makita ang reservation na buburahin.';
            header('Location: reservations.php');
            exit;
        }
    } elseif (
        (isset($_POST['approve_reservation']) || isset($_POST['reject_reservation']))
        && $isStaff
    ) {
        $reservationId = filter_var(
            $_POST['reservation_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        if ($reservationId === false) {
            $error = 'Hindi wasto ang reservation na pinili.';
        } else {
            // Kinukuha ang detalye ng reservation para sa notification sa resident.
            $reservationInfo = null;
            $reservationInfoStmt = $conn->prepare(
                'SELECT b.facility, b.date_reserved, b.time_reserved, b.time_to, r.user_id
                 FROM reservations b
                 JOIN residents r ON b.resident_id = r.resident_id
                 WHERE b.reservation_id = ?'
            );
            $reservationInfoStmt->bind_param('i', $reservationId);
            $reservationInfoStmt->execute();
            $reservationInfo = $reservationInfoStmt->get_result()->fetch_assoc();

            $reservationStatus = isset($_POST['approve_reservation']) ? 'Approved' : 'Not Approved';
            $decisionStmt = $conn->prepare(
                "UPDATE reservations SET status = ?
                 WHERE reservation_id = ? AND status = 'Pending'"
            );
            $decisionStmt->bind_param('si', $reservationStatus, $reservationId);
            $decisionStmt->execute();
            if ($decisionStmt->affected_rows > 0) {
                logAudit($conn, $userId, $reservationStatus === 'Approved' ? 'approve_reservation' : 'reject_reservation', $reservationStatus . ' ang reservation (reservation_id=' . $reservationId . ').');
                if ($reservationInfo) {
                    $reservationLabel = trim((string) ($reservationInfo['facility'] ?? ''));
                    $reservationFrom = !empty($reservationInfo['time_reserved'])
                        ? date('g:i A', strtotime((string) $reservationInfo['time_reserved']))
                        : '';
                    $reservationTo = !empty($reservationInfo['time_to'])
                        ? date('g:i A', strtotime((string) $reservationInfo['time_to']))
                        : '';
                    $reservationWhen = trim((string) ($reservationInfo['date_reserved'] ?? ''))
                        . ($reservationFrom !== '' ? ' ' . $reservationFrom : '')
                        . ($reservationTo !== '' ? ' - ' . $reservationTo : '');
                    if ($reservationStatus === 'Approved') {
                        notifyUser(
                            $conn,
                            (int) $reservationInfo['user_id'],
                            'reservation',
                            'Na-approve ang reservation mo',
                            'Na-approve ang reservation mo' . ($reservationLabel !== '' ? ' sa ' . $reservationLabel : '') . ($reservationWhen !== '' ? ' sa ' . $reservationWhen : '') . '.',
                            'reservations.php'
                        );
                    } else {
                        notifyUser(
                            $conn,
                            (int) $reservationInfo['user_id'],
                            'reservation',
                            'Hindi na-approve ang reservation mo',
                            'Hindi na-approve ang reservation mo' . ($reservationLabel !== '' ? ' sa ' . $reservationLabel : '') . ($reservationWhen !== '' ? ' sa ' . $reservationWhen : '') . '.',
                            'reservations.php'
                        );
                    }
                }
            }
            $updatedMessage = $reservationStatus === 'Approved'
                ? 'Matagumpay na na-approve ang reservation.'
                : 'Na-mark bilang Not Approved ang reservation.';
            $_SESSION['reservation_message'] = $decisionStmt->affected_rows > 0
                ? $updatedMessage
                : 'Hindi na pending ang reservation o hindi ito makita.';
            header('Location: reservations.php');
            exit;
        }
    } else {
        http_response_code(403);
        $error = 'Walang pahintulot para sa reservation action na ito.';
    }
}

// Staff ay nakakakita ng lahat; resident ay nakakakita lamang ng sariling reservation.
$reservationPageSize = 10;
$reservationPage = paginationPage();
$reservationTotalPages = 1;
$reservationSelect = 'SELECT b.reservation_id, b.facility, b.date_reserved, b.time_reserved, b.time_to, b.purpose, b.status,
                             u.full_name, r.block_lot
                      FROM reservations b
                      JOIN residents r ON b.resident_id = r.resident_id
                      JOIN users u ON r.user_id = u.user_id';

if ($isStaff) {
    $reservationCount = (int) $conn->query(
        'SELECT COUNT(*) AS total
         FROM reservations b
         JOIN residents r ON b.resident_id = r.resident_id
         JOIN users u ON r.user_id = u.user_id'
    )->fetch_assoc()['total'];
    $reservationTotalPages = max(1, (int) ceil($reservationCount / $reservationPageSize));
    $reservationPage = min($reservationPage, $reservationTotalPages);
    $reservationOffset = ($reservationPage - 1) * $reservationPageSize;
    $reservations = $conn->query(
        $reservationSelect . ' ORDER BY b.date_reserved DESC, b.reservation_id DESC'
        . ' LIMIT ' . $reservationPageSize . ' OFFSET ' . $reservationOffset
    );
} elseif ($isResident && $residentId > 0) {
    $reservationCountStmt = $conn->prepare('SELECT COUNT(*) AS total FROM reservations WHERE resident_id = ?');
    $reservationCountStmt->bind_param('i', $residentId);
    $reservationCountStmt->execute();
    $reservationCount = (int) $reservationCountStmt->get_result()->fetch_assoc()['total'];
    $reservationTotalPages = max(1, (int) ceil($reservationCount / $reservationPageSize));
    $reservationPage = min($reservationPage, $reservationTotalPages);
    $reservationOffset = ($reservationPage - 1) * $reservationPageSize;
    $reservationListStmt = $conn->prepare(
        $reservationSelect . ' WHERE b.resident_id = ? ORDER BY b.date_reserved DESC, b.reservation_id DESC'
        . ' LIMIT ' . $reservationPageSize . ' OFFSET ' . $reservationOffset
    );
    $reservationListStmt->bind_param('i', $residentId);
    $reservationListStmt->execute();
    $reservations = $reservationListStmt->get_result();
} else {
    $reservations = null;
}

require_once 'includes/header.php';
?>
<div class="page-header"><h2>Reservations</h2></div>
<p class="schedule-link"><a href="schedule.php">Tingnan ang iskedyul ng facility</a> para makita kung okupado na ang oras bago mag-reserve.</p>
<?php if ($error !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($message !== ''): ?>
  <p class="alert alert-success" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<?php if ($isResident): ?>
  <?php if ($residentId < 1): ?>
    <section class="card"><p>Wala pang resident profile na naka-link sa account mo. Makipag-ugnayan sa HOA officer.</p></section>
  <?php else: ?>
    <section class="card">
      <h3>Reserve a Facility</h3>
      <form class="form-grid" action="reservations.php" method="post">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
        <div class="form-field">
          <label for="facility">Facility</label>
          <select id="facility" name="facility" required>
            <option value="">-- Piliin ang facility --</option>
            <?php foreach ($facilities as $option): ?>
              <option value="<?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?>"<?= $facility === $option ? ' selected' : '' ?>><?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field">
          <label for="reservationDate">Date</label>
          <input id="reservationDate" type="date" name="date_reserved" min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($reservationDate, ENT_QUOTES, 'UTF-8') ?>" required>
        </div>
        <div class="form-field">
          <label for="reservationFromHour">From</label>
          <div class="time-select-group">
            <select id="reservationFromHour" name="time_from_hour" aria-label="From hour" required>
              <option value="">Hour</option>
              <?php foreach ($hours as $hour): ?>
                <option value="<?= $hour ?>"<?= $reservationFromHour === (string) $hour ? ' selected' : '' ?>><?= $hour ?></option>
              <?php endforeach; ?>
            </select>
            <span aria-hidden="true">:</span>
            <input id="reservationFromMinute" type="number" name="time_from_minute" min="0" max="59" step="1" value="<?= htmlspecialchars($reservationFromMinute, ENT_QUOTES, 'UTF-8') ?>" placeholder="00" aria-label="From minute (00-59)" required>
            <select name="time_from_period" aria-label="From AM or PM" required>
              <?php foreach ($periods as $period): ?>
                <option value="<?= $period ?>"<?= $reservationFromPeriod === $period ? ' selected' : '' ?>><?= $period ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-field">
          <label for="reservationToHour">To</label>
          <div class="time-select-group">
            <select id="reservationToHour" name="time_to_hour" aria-label="To hour" required>
              <option value="">Hour</option>
              <?php foreach ($hours as $hour): ?>
                <option value="<?= $hour ?>"<?= $reservationToHour === (string) $hour ? ' selected' : '' ?>><?= $hour ?></option>
              <?php endforeach; ?>
            </select>
            <span aria-hidden="true">:</span>
            <input id="reservationToMinute" type="number" name="time_to_minute" min="0" max="59" step="1" value="<?= htmlspecialchars($reservationToMinute, ENT_QUOTES, 'UTF-8') ?>" placeholder="00" aria-label="To minute (00-59)" required>
            <select name="time_to_period" aria-label="To AM or PM" required>
              <?php foreach ($periods as $period): ?>
                <option value="<?= $period ?>"<?= $reservationToPeriod === $period ? ' selected' : '' ?>><?= $period ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-field form-field-wide">
          <label for="reservationPurpose">Saan gagamitin ang facility?</label>
          <textarea id="reservationPurpose" name="purpose" rows="3" maxlength="150" placeholder="Hal. Birthday party" required><?= htmlspecialchars($purpose, ENT_QUOTES, 'UTF-8') ?></textarea>
        </div>
        <div class="form-actions"><button type="submit" name="create_reservation" value="1" class="btn btn-primary">Submit Reservation</button></div>
      </form>
    </section>
  <?php endif; ?>
<?php endif; ?>

<?php if ($isStaff || ($isResident && $residentId > 0)): ?>
  <section class="card">
    <div class="card-head"><h3><?= $isStaff ? 'All Reservations' : 'My Reservations' ?></h3></div>
    <div class="table-wrap reservation-table-wrap">
      <table class="table reservation-table">
        <thead><tr><?php if ($isStaff): ?><th>Resident</th><th>Block/Lot</th><?php endif; ?><th>Facility</th><th>Date</th><th>From</th><th>To</th><th>Purpose</th><th>Status</th><?php if ($isStaff): ?><th>Action</th><?php endif; ?></tr></thead>
        <tbody>
          <?php if ($reservations->num_rows === 0): ?>
            <tr><td colspan="<?= $isStaff ? '9' : '6' ?>">Wala pang reservations.</td></tr>
          <?php else: ?>
            <?php while ($reservation = $reservations->fetch_assoc()): ?>
              <tr>
                <?php if ($isStaff): ?>
                  <td><?= htmlspecialchars($reservation['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
                  <td><?= htmlspecialchars($reservation['block_lot'], ENT_QUOTES, 'UTF-8') ?></td>
                <?php endif; ?>
                <td><?= htmlspecialchars($reservation['facility'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars(date('M d, Y', strtotime($reservation['date_reserved'])), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= !empty($reservation['time_reserved']) ? htmlspecialchars(date('g:i A', strtotime($reservation['time_reserved'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                <td><?= !empty($reservation['time_to']) ? htmlspecialchars(date('g:i A', strtotime($reservation['time_to'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                <td><?= htmlspecialchars($reservation['purpose'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                <td><span class="badge <?= $reservation['status'] === 'Approved' ? 'badge-paid' : ($reservation['status'] === 'Not Approved' ? 'badge-unpaid' : 'badge-pending') ?>"><?= htmlspecialchars($reservation['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
                <?php if ($isStaff): ?>
                  <td>
                    <?php if ($reservation['status'] === 'Pending'): ?>
                      <div class="reservation-actions">
                        <form action="reservations.php" method="post" class="confirm-form" data-confirm="I-approve ang reservation na ito?">
                          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                          <input type="hidden" name="reservation_id" value="<?= (int) $reservation['reservation_id'] ?>">
                          <button type="submit" name="approve_reservation" value="1" class="btn btn-small">Approve</button>
                        </form>
                        <form action="reservations.php" method="post" class="confirm-form" data-confirm="Markahan bilang Not Approved ang reservation na ito?">
                          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                          <input type="hidden" name="reservation_id" value="<?= (int) $reservation['reservation_id'] ?>">
                          <button type="submit" name="reject_reservation" value="1" class="btn btn-small btn-danger">Not Approved</button>
                        </form>
                      </div>
                    <?php endif; ?>
                    <?php if ($isAdmin): ?>
                      <form action="reservations.php" method="post" class="confirm-form reservation-delete-form" data-confirm="Permanenteng buburahin ang reservation na ito. Hindi na ito maibabalik. Magpatuloy?">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="reservation_id" value="<?= (int) $reservation['reservation_id'] ?>">
                        <button type="submit" name="delete_reservation" value="1" class="btn btn-small btn-danger">Delete</button>
                      </form>
                    <?php endif; ?>
                  </td>
                <?php endif; ?>
              </tr>
            <?php endwhile; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php renderPagination($reservationPage, $reservationTotalPages); ?>
  </section>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
