<?php
// Staff page para magdagdag ng resident at makita ang kasalukuyang resident directory.
require_once 'includes/auth.php';
require_once 'includes/validation.php';

$pageTitle = 'Residents';
$role = $_SESSION['role'] ?? '';
$isStaff = in_array($role, ['admin', 'officer'], true);
$isAdmin = $role === 'admin';
$adminUserId = (int) ($_SESSION['user_id'] ?? 0);

// Tinatapos agad ang request ng ibang role bago magbukas o magpakita ng resident data.
if (!$isStaff) {
    http_response_code(403);
    require_once 'includes/header.php';
    ?>
    <div class="page-header"><h2>Residents</h2></div>
    <p class="alert" role="alert">Admin at Officer lang ang maaaring tumingin o mamahala ng resident records.</p>
    <?php
    require_once 'includes/footer.php';
    exit;
}

require_once 'includes/db.php';

/**
 * Kinukuha ang street lamang mula sa block_lot string (hal. "Blk 4 Lot 5, Pogi" -> "Pogi").
 */
function extractStreetOnly(?string $blockLot): string
{
    $value = trim((string) $blockLot);
    if ($value === '') {
        return '-';
    }

    $commaPos = strpos($value, ',');
    if ($commaPos !== false) {
        $streetPart = trim(substr($value, $commaPos + 1));
        return $streetPart !== '' ? $streetPart : '-';
    }

    // Kung walang comma (hal. lumang record na "Block 23, Lot 19" o "Block Lot 4"), hindi pinapakita ang Block/Lot bilang street.
    if (preg_match('/^(block|blk|lot)\b/i', $value)) {
        return '-';
    }

    return $value;
}

$error = '';
$success = $_SESSION['resident_message'] ?? '';
unset($_SESSION['resident_message']);
$fullName = '';
$email = '';
$blk = 1;
$lot = 1;
$street = '';
$householdMembers = '1';
$moveInDate = '';
$contactNo = '';

// Pinoprotektahan ang create form laban sa cross-site request forgery.
$csrfToken = csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (isset($_POST['remove_resident'])) {
        if (!$isAdmin) {
            http_response_code(403);
            $error = 'Admin lang ang maaaring magtanggal ng resident.';
        } else {
            $residentId = filter_var(
                $_POST['resident_id'] ?? null,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1]]
            );

            if ($residentId === false) {
                $error = 'Hindi wasto ang resident na pinili.';
            } else {
                $transactionStarted = false;
                try {
                    $conn->begin_transaction();
                    $transactionStarted = true;

                    $residentStmt = $conn->prepare(
                        "SELECT r.user_id
                         FROM residents r
                         INNER JOIN users u ON u.user_id = r.user_id
                         WHERE r.resident_id = ? AND u.role = 'resident'
                         FOR UPDATE"
                    );
                    $residentStmt->bind_param('i', $residentId);
                    $residentStmt->execute();
                    $resident = $residentStmt->get_result()->fetch_assoc();

                    if (!$resident) {
                        $conn->rollback();
                        $transactionStarted = false;
                        $error = 'Hindi makita ang resident na tatanggalin.';
                    } else {
                        $residentUserId = (int) $resident['user_id'];
                        $paymentFiles = [];
                        $paymentFileStmt = $conn->prepare(
                            "SELECT payment_proof FROM payments
                             WHERE resident_id = ? AND payment_proof IS NOT NULL AND payment_proof <> ''"
                        );
                        $paymentFileStmt->bind_param('i', $residentId);
                        $paymentFileStmt->execute();
                        $paymentFileResult = $paymentFileStmt->get_result();
                        while ($file = $paymentFileResult->fetch_assoc()) {
                            $paymentFiles[] = $file['payment_proof'];
                        }

                        $complaintFiles = [];
                        $complaintFileStmt = $conn->prepare(
                            "SELECT attachment_file FROM complaints
                             WHERE resident_id = ? AND attachment_file IS NOT NULL AND attachment_file <> ''"
                        );
                        $complaintFileStmt->bind_param('i', $residentId);
                        $complaintFileStmt->execute();
                        $complaintFileResult = $complaintFileStmt->get_result();
                        while ($file = $complaintFileResult->fetch_assoc()) {
                            $complaintFiles[] = $file['attachment_file'];
                        }

                        foreach (['payments', 'complaints', 'reservations'] as $table) {
                            $deleteRelatedStmt = $conn->prepare(
                                'DELETE FROM ' . $table . ' WHERE resident_id = ?'
                            );
                            $deleteRelatedStmt->bind_param('i', $residentId);
                            $deleteRelatedStmt->execute();
                        }

                        $deleteResidentStmt = $conn->prepare('DELETE FROM residents WHERE resident_id = ?');
                        $deleteResidentStmt->bind_param('i', $residentId);
                        $deleteResidentStmt->execute();

                        $deleteUserStmt = $conn->prepare(
                            "DELETE FROM users WHERE user_id = ? AND role = 'resident'"
                        );
                        $deleteUserStmt->bind_param('i', $residentUserId);
                        $deleteUserStmt->execute();

                        if ($deleteUserStmt->affected_rows !== 1) {
                            $conn->rollback();
                            $transactionStarted = false;
                            $error = 'Hindi natanggal ang resident account. Walang naburang record.';
                        } else {
                            $conn->commit();
                            $transactionStarted = false;
                            logAudit($conn, $adminUserId, 'remove_resident', 'Tinanggal ang resident (resident_id=' . $residentId . ', user_id=' . $residentUserId . ').');

                            $attachmentCleanupFailed = false;
                            $fileLocations = [
                                [
                                    'files' => $paymentFiles,
                                    'directory' => dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'hoa-payment-proofs',
                                ],
                                [
                                    'files' => $complaintFiles,
                                    'directory' => dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'hoa-complaint-attachments',
                                ],
                            ];
                            foreach ($fileLocations as $location) {
                                foreach ($location['files'] as $filename) {
                                    $filename = (string) $filename;
                                    if (
                                        $filename === ''
                                        || $filename === '.'
                                        || $filename === '..'
                                        || strpos($filename, "\0") !== false
                                        || basename(str_replace('\\', '/', $filename)) !== $filename
                                    ) {
                                        $attachmentCleanupFailed = true;
                                        error_log('Resident removal found an invalid attachment filename.');
                                        continue;
                                    }

                                    $filePath = $location['directory'] . DIRECTORY_SEPARATOR . $filename;
                                    if (is_file($filePath) && !unlink($filePath)) {
                                        $attachmentCleanupFailed = true;
                                        error_log('Resident removal could not delete an attachment file.');
                                    }
                                }
                            }

                            $_SESSION['resident_message'] = $attachmentCleanupFailed
                                ? 'Nabura ang resident account at mga record, pero may attachment file na hindi naalis. Ipa-check ito sa admin.'
                                : 'Permanenteng nabura ang resident account at lahat ng kaugnay na record.';
                            header('Location: residents.php');
                            exit;
                        }
                    }
                } catch (mysqli_sql_exception $exception) {
                    if ($transactionStarted) {
                        $conn->rollback();
                    }
                    error_log('Resident removal failed: ' . $exception->getMessage());
                    $error = 'Hindi natanggal ang resident. Subukan muli.';
                }
            }
        }
    } elseif (isset($_POST['approve_resident'])) {
        if (!$isAdmin) {
            http_response_code(403);
            $error = 'Admin lang ang maaaring mag-approve ng account.';
        } else {
            $pendingUserId = filter_var(
                $_POST['user_id'] ?? null,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1]]
            );

            if ($pendingUserId === false) {
                $error = 'Hindi wasto ang account na pinili.';
            } elseif (!usersHasAccountStatus($conn)) {
                $error = 'Hindi pa naka-apply ang approval migration. Patakbuhin muna ang migrations/006_add_account_status.sql.';
            } else {
                $approveStmt = $conn->prepare(
                    "UPDATE users SET account_status = 'approved'
                     WHERE user_id = ? AND role = 'resident' AND account_status = 'pending'"
                );
                $approveStmt->bind_param('i', $pendingUserId);
                $approveStmt->execute();
                if ($approveStmt->affected_rows > 0) {
                    logAudit($conn, $adminUserId, 'approve_resident', 'Na-approve ang resident account (user_id=' . $pendingUserId . ').');
                    $_SESSION['resident_message'] = 'Na-approve ang account. Maaari nang mag-login ang resident.';
                } else {
                    $_SESSION['resident_message'] = 'Hindi na pending ang account na ito o hindi ito makita.';
                }
                header('Location: residents.php');
                exit;
            }
        }
    } elseif (isset($_POST['reject_resident'])) {
        if (!$isAdmin) {
            http_response_code(403);
            $error = 'Admin lang ang maaaring tumanggi ng account.';
        } else {
            $pendingUserId = filter_var(
                $_POST['user_id'] ?? null,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1]]
            );

            if ($pendingUserId === false) {
                $error = 'Hindi wasto ang account na pinili.';
            } elseif (!usersHasAccountStatus($conn)) {
                $error = 'Hindi pa naka-apply ang approval migration. Patakbuhin muna ang migrations/006_add_account_status.sql.';
            } else {
                $rejectStarted = false;
                try {
                    $conn->begin_transaction();
                    $rejectStarted = true;

                    $rejectResidentStmt = $conn->prepare('DELETE FROM residents WHERE user_id = ?');
                    $rejectResidentStmt->bind_param('i', $pendingUserId);
                    $rejectResidentStmt->execute();

                    $rejectUserStmt = $conn->prepare(
                        "DELETE FROM users WHERE user_id = ? AND role = 'resident' AND account_status = 'pending'"
                    );
                    $rejectUserStmt->bind_param('i', $pendingUserId);
                    $rejectUserStmt->execute();

                    if ($rejectUserStmt->affected_rows > 0) {
                        $conn->commit();
                        $rejectStarted = false;
                        logAudit($conn, $adminUserId, 'reject_resident', 'Tinanggihan at binura ang resident account (user_id=' . $pendingUserId . ').');
                        $_SESSION['resident_message'] = 'Tinanggihan at nabura ang account.';
                    } else {
                        $conn->rollback();
                        $rejectStarted = false;
                        $_SESSION['resident_message'] = 'Hindi na pending ang account na ito o hindi ito makita.';
                    }
                    header('Location: residents.php');
                    exit;
                } catch (mysqli_sql_exception $exception) {
                    if ($rejectStarted) {
                        $conn->rollback();
                    }
                    error_log('Resident approval rejection failed: ' . $exception->getMessage());
                    $error = 'Hindi natanggihan ang account. Subukan muli.';
                }
            }
        }
    } else {
        $fullName = trim(post_string('full_name'));
        $email = trim(post_string('email'));

        $blkInput = filter_input(INPUT_POST, 'blk', FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1, 'max_range' => 100]
        ]);
        $lotInput = filter_input(INPUT_POST, 'lot', FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1, 'max_range' => 100]
        ]);
        $blk = ($blkInput !== false && $blkInput !== null) ? $blkInput : 0;
        $lot = ($lotInput !== false && $lotInput !== null) ? $lotInput : 0;
        $street = trim(post_string('street'));

        $householdMembers = trim(post_string('household_members'));
        $moveInDate = trim(post_string('move_in_date'));
        $contactNo = trim(post_string('contact_no'));
        $password = post_string('password');

        // Hanggang 4-digit year lang ang tinatanggap sa Move-in Date.
        $validMoveInDate = $moveInDate === '';
        if ($moveInDate !== '') {
            if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $moveInDate, $matches)) {
                $year = (int) $matches[1];
                $parsedMoveInDate = DateTime::createFromFormat('!Y-m-d', $moveInDate);
                $validMoveInDate = $year >= 1000 && $year <= 9999
                    && $parsedMoveInDate !== false
                    && $parsedMoveInDate->format('Y-m-d') === $moveInDate;
            } else {
                $validMoveInDate = false;
            }
        }

        if (!isValidPhilippineMobileNumber($contactNo)) {
            $error = 'Maglagay ng kapani-paniwalang 11-digit mobile number na nagsisimula sa 09.';
        } elseif ($blk === 0 || $lot === 0) {
            $error = 'Maglagay ng wastong Block (1–100) at Lot (1–100).';
        } elseif ($street === '' || mb_strlen($street) > 50) {
            $error = 'Maglagay ng wastong Street (1 hanggang 50 character).';
        } elseif (!$validMoveInDate) {
            $error = 'Ang taon sa Move-in Date ay dapat hanggang 4 na digit lamang (YYYY-MM-DD).';
        } elseif (!isValidNewPassword($password)) {
            $error = 'Ang password ay dapat 12 hanggang 64 character.';
        } elseif (
            $fullName === ''
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
            || filter_var($householdMembers, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) === false
        ) {
            $error = 'Punan nang tama ang lahat ng kinakailangang field.';
        } else {
            // Isinusulat ang user at resident profile bilang isang transaksyon.
            $householdMembers = (int) $householdMembers;
            $moveInDate = $moveInDate === '' ? null : $moveInDate;
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $blockLotDisplay = mb_substr("Blk {$blk} Lot {$lot}, {$street}", 0, 50);

            try {
                $conn->begin_transaction();

                if (usersHasAccountStatus($conn)) {
                    // Direktang approved ang account na idinagdag mismo ng staff.
                    $userStmt = $conn->prepare(
                        "INSERT INTO users (full_name, email, password, role, contact_no, account_status)
                         VALUES (?, ?, ?, 'resident', ?, 'approved')"
                    );
                } else {
                    $userStmt = $conn->prepare(
                        "INSERT INTO users (full_name, email, password, role, contact_no)
                         VALUES (?, ?, ?, 'resident', ?)"
                    );
                }
                $userStmt->bind_param('ssss', $fullName, $email, $passwordHash, $contactNo);
                $userStmt->execute();
                $userId = $conn->insert_id;

                $residentStmt = $conn->prepare(
                    'INSERT INTO residents (user_id, blk, lot, block_lot, household_members, move_in_date)
                     VALUES (?, ?, ?, ?, ?, ?)'
                );
                $residentStmt->bind_param('iiisis', $userId, $blk, $lot, $blockLotDisplay, $householdMembers, $moveInDate);
                $residentStmt->execute();

                $conn->commit();
                header('Location: residents.php?added=1');
                exit;
            } catch (mysqli_sql_exception $exception) {
                $conn->rollback();
                error_log('Resident creation failed: ' . $exception->getMessage());

                if ($exception->getCode() === 1062) {
                    $error = 'May account na gamit ang email na ito.';
                } else {
                    $error = 'Hindi naidagdag ang resident. Subukan muli.';
                }
            }
        }
    }
}

// Inihahanda ang kumpletong directory na ipapakita sa staff.
$accountStatusColumn = usersHasAccountStatus($conn) ? ', u.account_status' : '';
$result = $conn->query(
    'SELECT r.resident_id, r.blk, r.lot, r.block_lot, r.household_members, r.move_in_date, r.status,
            u.user_id, u.full_name, u.email, u.contact_no' . $accountStatusColumn . '
     FROM residents r
     LEFT JOIN users u ON r.user_id = u.user_id
     ORDER BY r.blk, r.lot, r.resident_id'
);

// Mga account na nag-register online at naghihintay ng approval ng admin.
$pendingAccounts = null;
if ($isAdmin && usersHasAccountStatus($conn)) {
    $pendingStmt = $conn->prepare(
        "SELECT u.user_id, u.full_name, u.email, u.contact_no, r.blk, r.lot, r.block_lot
         FROM users u
         LEFT JOIN residents r ON r.user_id = u.user_id
         WHERE u.role = 'resident' AND u.account_status = 'pending'
         ORDER BY u.user_id"
    );
    $pendingStmt->execute();
    $pendingAccounts = $pendingStmt->get_result();
}

if (isset($_GET['added'])) {
    $success = 'Matagumpay na naidagdag ang resident.';
}

require_once 'includes/header.php';
?>
<div class="page-header"><h2>Residents</h2></div>
<?php if ($error !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($success !== ''): ?>
  <p class="alert alert-success" role="status"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($pendingAccounts !== null && $pendingAccounts->num_rows > 0): ?>
<section class="card">
  <h3>Naghihintay ng Approval (<?= (int) $pendingAccounts->num_rows ?>)</h3>
  <p class="muted">Ang mga account na ito ay nag-register online at hindi pa makakapag-login hangga't hindi na-a-approve.</p>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>Pangalan</th><th>Email</th><th>Block</th><th>Lot</th><th>Street</th><th>Contact</th><th>Action</th></tr></thead>
      <tbody>
        <?php while ($pending = $pendingAccounts->fetch_assoc()): ?>
          <?php
            $pBlk = (int) ($pending['blk'] ?? 0);
            $pLot = (int) ($pending['lot'] ?? 0);
          ?>
          <tr>
            <td><?= htmlspecialchars($pending['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($pending['email'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= $pBlk > 0 ? 'Block ' . $pBlk : '-' ?></td>
            <td><?= $pLot > 0 ? 'Lot ' . $pLot : '-' ?></td>
            <td><?= htmlspecialchars(extractStreetOnly($pending['block_lot'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($pending['contact_no'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
            <td>
              <form action="residents.php" method="post" style="display:inline;">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="user_id" value="<?= (int) $pending['user_id'] ?>">
                <button type="submit" name="approve_resident" value="1" class="btn btn-small">Approve</button>
              </form>
              <form action="residents.php" method="post" class="confirm-form" data-confirm="Tatanggihan at buburahin ang account na ito. Magpatuloy?" style="display:inline;">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="user_id" value="<?= (int) $pending['user_id'] ?>">
                <button type="submit" name="reject_resident" value="1" class="btn btn-small btn-danger">Reject</button>
              </form>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>
<section class="card">
  <h3>Add Resident</h3>
  <form class="form-grid" action="residents.php" method="post">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
    <div class="form-field">
      <label for="residentName">Full Name</label>
      <input id="residentName" type="text" name="full_name" value="<?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>" placeholder="Juan Dela Cruz" required>
    </div>
    <div class="form-field">
      <label for="residentEmail">Email</label>
      <input id="residentEmail" type="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" placeholder="sample123@gmail.com" autocomplete="email" required>
    </div>
    <div class="form-field">
      <label for="residentPassword">Temporary Password (12-64 characters)</label>
      <div class="password-field">
        <input id="residentPassword" type="password" name="password" minlength="12" maxlength="64" autocomplete="new-password" required>
        <button type="button" class="password-toggle" data-password-toggle="residentPassword" aria-label="Ipakita ang password" aria-pressed="false">
          <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
        </button>
      </div>
    </div>
    <div class="form-field">
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; width: 100%;">
        <div>
          <label for="residentBlk">Block</label>
          <input id="residentBlk" type="number" name="blk" min="1" max="100" step="1" value="<?= htmlspecialchars((string) $blk, ENT_QUOTES, 'UTF-8') ?>" style="width: 100%;" required>
        </div>
        <div>
          <label for="residentLot">Lot</label>
          <input id="residentLot" type="number" name="lot" min="1" max="100" step="1" value="<?= htmlspecialchars((string) $lot, ENT_QUOTES, 'UTF-8') ?>" style="width: 100%;" required>
        </div>
      </div>
    </div>
    <div class="form-field">
      <label for="residentStreet">Street</label>
      <input id="residentStreet" type="text" name="street" maxlength="50" value="<?= htmlspecialchars($street, ENT_QUOTES, 'UTF-8') ?>" placeholder="Hal. Sampaguita St." required>
    </div>
    <div class="form-field">
      <label for="householdMembers">Household Members</label>
      <input id="householdMembers" type="number" name="household_members" min="1" value="<?= htmlspecialchars($householdMembers, ENT_QUOTES, 'UTF-8') ?>" required>
    </div>
    <div class="form-field">
      <label for="moveInDate">Move-in Date</label>
      <input id="moveInDate" type="date" name="move_in_date" min="1000-01-01" max="9999-12-31" value="<?= htmlspecialchars($moveInDate, ENT_QUOTES, 'UTF-8') ?>">
    </div>
    <div class="form-field">
      <label for="residentContact">Contact</label>
      <input id="residentContact" type="tel" name="contact_no" data-validate-ph-mobile value="<?= htmlspecialchars($contactNo, ENT_QUOTES, 'UTF-8') ?>" placeholder="09XXXXXXXXX" minlength="11" maxlength="11" pattern="09[0-9]{9}" inputmode="numeric" autocomplete="tel" title="Kapani-paniwalang 11 digit na numero na nagsisimula sa 09" required>
    </div>
    <div class="form-actions"><button type="submit" class="btn btn-primary">Add Resident</button></div>
  </form>
</section>
<section class="card">
  <div class="card-head">
    <h3>Residents List</h3>
    <input type="search" id="searchInput" placeholder="Mag-search ng pangalan..." aria-label="Search residents">
  </div>
  <div class="table-wrap admin-responsive-table">
    <table class="table" id="dataTable">
      <thead><tr><th>Pangalan</th><th>Email</th><th>Block</th><th>Lot</th><th>Street</th><th>Household</th><th>Move-in Date</th><th>Contact</th><?php if (!$isAdmin): ?><th>Status</th><?php endif; ?><?php if ($isAdmin): ?><th>Action</th><?php endif; ?></tr></thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <?php
            $rowBlk = (int) ($row['blk'] ?? 0);
            $rowLot = (int) ($row['lot'] ?? 0);
          ?>
          <tr>
            <td><?= htmlspecialchars($row['full_name'] ?? '', ENT_QUOTES, 'UTF-8') ?><?php if (($row['account_status'] ?? 'approved') === 'pending'): ?> <span class="badge badge-pending">Pending Approval</span><?php endif; ?></td>
            <td><?= htmlspecialchars($row['email'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= $rowBlk > 0 ? 'Block ' . $rowBlk : '-' ?></td>
            <td><?= $rowLot > 0 ? 'Lot ' . $rowLot : '-' ?></td>
            <td><?= htmlspecialchars(extractStreetOnly($row['block_lot'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars((string) $row['household_members'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($row['move_in_date'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($row['contact_no'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
            <?php if (!$isAdmin): ?>
              <td><?= htmlspecialchars($row['status'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
            <?php endif; ?>
            <?php if ($isAdmin): ?>
              <td>
                <form action="residents.php" method="post" class="confirm-form" data-confirm="Permanenteng buburahin ang resident, account, payments, complaints, reservations, at mga attachment. Hindi na ito maibabalik. Magpatuloy?">
                  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                  <input type="hidden" name="resident_id" value="<?= (int) $row['resident_id'] ?>">
                  <button type="submit" name="remove_resident" value="1" class="btn btn-danger btn-small">Remove</button>
                </form>
              </td>
            <?php endif; ?>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</section>
<script>
(function () {
  var dateInput = document.getElementById('moveInDate');
  if (!dateInput) return;

  function clampFourDigitYear() {
    var val = dateInput.value;
    if (!val) return;
    var parts = val.split('-');
    if (parts[0] && parts[0].length > 4) {
      parts[0] = parts[0].slice(0, 4);
      dateInput.value = parts.join('-');
    }
  }

  dateInput.addEventListener('input', clampFourDigitYear);
  dateInput.addEventListener('change', clampFourDigitYear);
})();
</script>
<?php require_once 'includes/footer.php'; ?>