<?php
// Dashboard pa rin ang unang pahina ng mga naka-login na user.
require_once 'includes/helpers.php';
start_secure_session();
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <link rel="icon" type="image/png" href="favicon.png?v=<?= (int) filemtime(__DIR__ . '/favicon.png') ?>">
  <link rel="manifest" href="manifest.webmanifest">
  <meta name="theme-color" content="#193b34">
  <link rel="apple-touch-icon" href="assets/images/icon-192.png?v=<?= (int) filemtime(__DIR__ . '/assets/images/icon-192.png') ?>">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Opisyal na online portal para sa mga serbisyo at anunsyo ng Adelina 3 Homeowners Association.">
  <title>Adelina 3 Homeowners Association</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.9/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/css/style.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/style.css') ?>">
  <link rel="stylesheet" href="assets/css/redesign.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/redesign.css') ?>">
</head>
<body class="landing-page">
  <header class="landing-nav">
    <a class="landing-brand" href="landing.php" aria-label="Adelina 3 Homeowners Association - Home">
      <img src="assets/images/logo.png?v=<?= (int) filemtime(__DIR__ . '/assets/images/logo.png') ?>" alt="Adelina 3 Homeowners Association logo">
    </a>
    <nav class="landing-nav-actions" aria-label="Main navigation">
      <a class="landing-nav-link" href="#services" data-i18n="nav.services">Mga Serbisyo</a>
      <a class="btn landing-login" href="login.php" data-i18n="nav.login">Mag-login</a>
      <a class="btn btn-primary" href="register.php" data-i18n="nav.register">Mag-register</a>
      <button id="themeToggle" type="button" class="btn btn-sm btn-light rounded-circle border ms-1" title="Toggle Dark Mode" style="width: 38px; height: 38px;">
        <i class="bi bi-moon-fill" id="themeIcon"></i>
      </button>

    </nav>
  </header>

  <main>
    <section class="landing-hero">
      <div class="landing-hero-copy">
        <p class="landing-eyebrow"><span aria-hidden="true"></span> Adelina 3 Homeowners Association</p>
        <h1 data-i18n="hero.title">Mas maayos na serbisyo para sa ating komunidad.</h1>
        <p class="landing-intro" data-i18n="hero.intro">Gamitin ang online portal para mas madaling makita ang mga anunsyo, pamahalaan ang bayarin, at magpadala ng mga request sa HOA.</p>
        <div class="landing-hero-actions">
          <a class="btn btn-primary" href="register.php"><span data-i18n="hero.cta1">Gumawa ng account</span> <span aria-hidden="true">&rarr;</span></a>
          <a class="landing-secondary-link" href="login.php" data-i18n="hero.cta2">May account na? Mag-login</a>
        </div>
        <p class="landing-note" data-i18n="hero.note">Para sa mga residente at miyembro ng Adelina 3.</p>
      </div>
      <div class="landing-portal-card" aria-label="Mga serbisyo sa resident portal">
        <div class="landing-portal-heading">
          <span class="landing-portal-icon" aria-hidden="true">A3</span>
          <span><strong>Resident Portal</strong><small data-i18n="portal.sub">Mga serbisyo ng komunidad</small></span>
        </div>
        <div class="landing-portal-item"><span aria-hidden="true">01</span><div><strong data-i18n="portal.item1t">Bayarin</strong><small data-i18n="portal.item1d">Tingnan ang dues at payment status</small></div></div>
        <div class="landing-portal-item"><span aria-hidden="true">02</span><div><strong data-i18n="portal.item2t">Anunsyo</strong><small data-i18n="portal.item2d">Basahin ang mga update ng HOA</small></div></div>
        <div class="landing-portal-item"><span aria-hidden="true">03</span><div><strong data-i18n="portal.item3t">Mga Request</strong><small data-i18n="portal.item3d">Mag-book o magpadala ng concern</small></div></div>
        <div class="landing-portal-footer"><span aria-hidden="true"></span> <span data-i18n="portal.footer">Isang portal para sa ating komunidad</span></div>
      </div>
    </section>

    <section class="landing-services" id="services">
      <div class="landing-section-heading">
        <p class="landing-eyebrow" data-i18n="services.eyebrow">MGA SERBISYO</p>
        <h2 data-i18n="services.title">Mas madaling asikasuhin online</h2>
        <p data-i18n="services.sub">Mag-login para ma-access ang mga serbisyo ng HOA portal.</p>
      </div>
      <div class="landing-service-grid">
        <article class="landing-service-card">
          <span class="landing-service-icon" aria-hidden="true">₱</span>
          <h3 data-i18n="svc1t">Bayarin at Payments</h3>
          <p data-i18n="svc1d">Subaybayan ang dues at tingnan ang status ng ipinadalang bayad.</p>
        </article>
        <article class="landing-service-card">
          <span class="landing-service-icon" aria-hidden="true">A</span>
          <h3 data-i18n="svc2t">Mga Anunsyo</h3>
          <p data-i18n="svc2d">Manatiling updated sa mahahalagang balita at anunsyo ng HOA.</p>
        </article>
        <article class="landing-service-card">
          <span class="landing-service-icon" aria-hidden="true">R</span>
          <h3>Reservations</h3>
          <p data-i18n="svc3d">Magpadala at subaybayan ang reservation request para sa pasilidad.</p>
        </article>
        <article class="landing-service-card">
          <span class="landing-service-icon" aria-hidden="true">C</span>
          <h3 data-i18n="svc4t">Complaints at Concerns</h3>
          <p data-i18n="svc4d">Ipaabot sa HOA ang mga concern at tingnan ang update sa status.</p>
        </article>
      </div>
    </section>

    <section class="landing-cta">
      <div>
        <p class="landing-eyebrow" data-i18n="cta.eyebrow">SIMULAN DITO</p>
        <h2 data-i18n="cta.title">May resident account ka na?</h2>
        <p data-i18n="cta.sub">Mag-login para buksan ang dashboard at gamitin ang HOA portal.</p>
      </div>
      <a class="btn btn-primary" href="login.php"><span data-i18n="cta.btn">Buksan ang portal</span> <span aria-hidden="true">&rarr;</span></a>
    </section>
  </main>

  <footer class="landing-footer">
    <span>Adelina 3 Homeowners Association</span>
    <span>
      <a href="privacy.php">Privacy Policy</a>
      &middot;
      <a href="terms.php">Terms &amp; Conditions</a>
    </span>
    <span>&copy; <?= date('Y') ?> Adelina 3 HOA</span>
  </footer>
  <!-- Cookie consent banner: lumalabas lang hangga't hindi pa pumipili ang user. -->
  <div class="cookie-banner" id="cookieBanner" hidden>
    <p><span data-i18n="cookie.text">Gumagamit ang site na ito ng cookies para mapanatili kang naka-login. Basahin ang aming</span> <a href="privacy.php">Privacy Policy</a>.</p>
    <div class="cookie-banner-actions">
      <button type="button" class="btn btn-primary btn-small" id="cookieAccept" data-i18n="cookie.accept">Tanggapin</button>
      <button type="button" class="btn btn-small" id="cookieDecline" data-i18n="cookie.decline">Tanggihan</button>
    </div>
  </div>
  <script src="assets/js/script.js?v=<?= (int) filemtime(__DIR__ . '/assets/js/script.js') ?>"></script>
  <script>
  (function () {
    const html = document.documentElement;
    const btn = document.getElementById('themeToggle');
    const icon = document.getElementById('themeIcon');

    if (localStorage.getItem('theme') === 'dark') {
      html.setAttribute('data-theme', 'dark');
      if (icon) icon.className = 'bi bi-sun-fill text-warning';
    }

    if (btn) {
      btn.addEventListener('click', function () {
        const isDark = html.getAttribute('data-theme') === 'dark';
        if (isDark) {
          html.removeAttribute('data-theme');
          localStorage.setItem('theme', 'light');
          if (icon) icon.className = 'bi bi-moon-fill';
        } else {
          html.setAttribute('data-theme', 'dark');
          localStorage.setItem('theme', 'dark');
          if (icon) icon.className = 'bi bi-sun-fill text-warning';
        }
      });
    }
  })();
</script>

</body>
</html>
