<?php
// Ipinapakita rito ang magkakaibang buod para sa staff at sa naka-login na resident.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Dashboard';
$role = strtolower($_SESSION['role'] ?? 'resident');
$isStaff = in_array($role, ['admin', 'officer'], true);
$userId = (int) $_SESSION['user_id'];
$residentId = 0;

// Hinahanap ang resident record upang ma-filter sa sariling account ang mga bilang.
if (!$isStaff) {
    $residentStmt = $conn->prepare('SELECT resident_id FROM residents WHERE user_id = ? LIMIT 1');
    $residentStmt->bind_param('i', $userId);
    $residentStmt->execute();
    $resident = $residentStmt->get_result()->fetch_assoc();
    if ($resident) {
        $residentId = (int) $resident['resident_id'];
    }
}

// Kinukuha ang angkop na mga bilang depende sa role.
if ($isStaff) {
    $stats = [
        ['Total Residents', (int) $conn->query("SELECT COUNT(*) AS c FROM residents WHERE status = 'active'")->fetch_assoc()['c']],
        ['Unpaid Dues', (int) $conn->query("SELECT COUNT(*) AS c FROM payments WHERE status = 'Unpaid'")->fetch_assoc()['c']],
        ['Open Complaints', (int) $conn->query("SELECT COUNT(*) AS c FROM complaints WHERE status != 'Resolved'")->fetch_assoc()['c']],
        ['Reservations', (int) $conn->query('SELECT COUNT(*) AS c FROM reservations')->fetch_assoc()['c']],
    ];
} else {
    $stats = [
        ['My Unpaid Dues', 0],
        ['My Open Complaints', 0],
        ['My Reservations', 0],
        ['Announcements', (int) $conn->query('SELECT COUNT(*) AS c FROM announcements')->fetch_assoc()['c']],
    ];

    if ($residentId > 0) {
        $unpaidStmt = $conn->prepare("SELECT COUNT(*) AS c FROM payments WHERE resident_id = ? AND status = 'Unpaid'");
        $unpaidStmt->bind_param('i', $residentId);
        $unpaidStmt->execute();
        $stats[0][1] = (int) $unpaidStmt->get_result()->fetch_assoc()['c'];

        $complaintsStmt = $conn->prepare("SELECT COUNT(*) AS c FROM complaints WHERE resident_id = ? AND status != 'Resolved'");
        $complaintsStmt->bind_param('i', $residentId);
        $complaintsStmt->execute();
        $stats[1][1] = (int) $complaintsStmt->get_result()->fetch_assoc()['c'];

        $reservationsStmt = $conn->prepare('SELECT COUNT(*) AS c FROM reservations WHERE resident_id = ?');
        $reservationsStmt->bind_param('i', $residentId);
        $reservationsStmt->execute();
        $stats[2][1] = (int) $reservationsStmt->get_result()->fetch_assoc()['c'];
    }
}

// Pareho ang announcement list na ipinapakita sa staff at resident dashboard.
$latestAnnouncements = $conn->query(
    'SELECT title, body, date_posted FROM announcements ORDER BY date_posted DESC, announcement_id DESC LIMIT 3'
);
$announcementRows = [];
while ($announcement = $latestAnnouncements->fetch_assoc()) {
    $announcementRows[] = $announcement;
}

// Kinukuha ang datos para sa mga chart sa dashboard.
// Staff: lahat ng bayad at reklamo. Resident: sariling bayad at reklamo lang.
$buwanPangalan = [
    '01' => 'Enero', '02' => 'Pebrero', '03' => 'Marso', '04' => 'Abril',
    '05' => 'Mayo', '06' => 'Hunyo', '07' => 'Hulyo', '08' => 'Agosto',
    '09' => 'Setyembre', '10' => 'Oktubre', '11' => 'Nobyembre', '12' => 'Disyembre',
];

// Kasaysayan ng bayad: kabuuang Paid bawat buwan, huling 6 na buwan.
$paymentChartSql = "SELECT DATE_FORMAT(date_paid, '%Y-%m') AS buwan, SUM(amount) AS kabuuan "
    . 'FROM payments WHERE status = \'Paid\' AND date_paid IS NOT NULL';
if (!$isStaff) {
    $paymentChartSql .= ' AND resident_id = ?';
}
$paymentChartSql .= ' GROUP BY buwan ORDER BY buwan DESC LIMIT 6';
if ($isStaff) {
    $paymentChartResult = $conn->query($paymentChartSql);
} else {
    $paymentChartStmt = $conn->prepare($paymentChartSql);
    $paymentChartStmt->bind_param('i', $residentId);
    $paymentChartStmt->execute();
    $paymentChartResult = $paymentChartStmt->get_result();
}
$paymentChartRows = [];
$paymentChartMax = 0.0;
while ($paymentChartRow = $paymentChartResult->fetch_assoc()) {
    $kabuuan = (float) $paymentChartRow['kabuuan'];
    [$taon, $buwan] = explode('-', (string) $paymentChartRow['buwan']);
    $paymentChartRows[] = [
        'label' => ($buwanPangalan[$buwan] ?? $buwan) . ' ' . $taon,
        'kabuuan' => $kabuuan,
        'pct' => 0.0,
    ];
    if ($kabuuan > $paymentChartMax) {
        $paymentChartMax = $kabuuan;
    }
}
$paymentChartRows = array_reverse($paymentChartRows);
foreach ($paymentChartRows as &$paymentChartRow) {
    $paymentChartRow['pct'] = $paymentChartMax > 0 ? ($paymentChartRow['kabuuan'] / $paymentChartMax) * 100 : 0;
}
unset($paymentChartRow);

// Katayuan ng mga reklamo: bilang bawat status (Pending / In Progress / Resolved).
$complaintChartSql = 'SELECT status, COUNT(*) AS bilang FROM complaints';
if (!$isStaff) {
    $complaintChartSql .= ' WHERE resident_id = ?';
}
$complaintChartSql .= ' GROUP BY status';
if ($isStaff) {
    $complaintChartResult = $conn->query($complaintChartSql);
} else {
    $complaintChartStmt = $conn->prepare($complaintChartSql);
    $complaintChartStmt->bind_param('i', $residentId);
    $complaintChartStmt->execute();
    $complaintChartResult = $complaintChartStmt->get_result();
}
$complaintChartBilang = ['Pending' => 0, 'In Progress' => 0, 'Resolved' => 0];
while ($complaintChartRow = $complaintChartResult->fetch_assoc()) {
    $statusKey = (string) ($complaintChartRow['status'] ?? '');
    if (array_key_exists($statusKey, $complaintChartBilang)) {
        $complaintChartBilang[$statusKey] = (int) $complaintChartRow['bilang'];
    }
}
$complaintChartTotal = array_sum($complaintChartBilang);
$complaintChartRows = [
    ['label' => 'Naghihintay', 'class' => 'chart-fill-pending', 'bilang' => $complaintChartBilang['Pending']],
    ['label' => 'Ginagawa', 'class' => 'chart-fill-progress', 'bilang' => $complaintChartBilang['In Progress']],
    ['label' => 'Nalutas', 'class' => 'chart-fill-resolved', 'bilang' => $complaintChartBilang['Resolved']],
];
foreach ($complaintChartRows as &$complaintChartRow) {
    $complaintChartRow['pct'] = $complaintChartTotal > 0 ? ($complaintChartRow['bilang'] / $complaintChartTotal) * 100 : 0;
}
unset($complaintChartRow);


// Ipinapasa ang nakalkulang datos sa iisang shared page layout at sa dashboard view.
require_once 'includes/header.php';
require __DIR__ . '/views/dashboard.view.php';
require_once 'includes/footer.php';
