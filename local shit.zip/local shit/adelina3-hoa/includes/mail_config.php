<?php
// Mga setting ng Gmail SMTP para sa OTP email. Itakda ang password sa
// HOA_MAIL_PASSWORD environment variable.
$mailConfig = [
    'host' => 'smtp.gmail.com',
    'port' => 465,
    'username' => 'adelinahomeownersassociation@gmail.com',
    'from_name' => 'Adelina 3 HOA',
];
