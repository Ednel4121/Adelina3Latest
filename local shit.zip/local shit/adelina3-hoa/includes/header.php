<?php
// Ibinabahagi ng lahat ng authenticated page ang title, navigation at pambungad na HTML layout.
require_once __DIR__ . '/auth.php';
$pageTitle = $pageTitle ?? 'Adelina 3 Homeowners Association';
$currentPage = basename($_SERVER['PHP_SELF']);
$userName = trim((string) ($_SESSION['full_name'] ?? ''));
$userRole = ucfirst((string) ($_SESSION['role'] ?? ''));
$showUserRole = $userName === '' || strcasecmp($userName, $userRole) !== 0;
// Bilang ng hindi pa nababasang notification para sa bell icon.
$unreadCount = 0;
if (isset($conn, $_SESSION['user_id']) && function_exists('unreadNotificationCount')) {
    $unreadCount = unreadNotificationCount($conn, (int) $_SESSION['user_id']);
}

// Nasa views/layout/top.php ang pambungad na HTML (head, sidebar, topbar) para iisa lang ang source.
require __DIR__ . '/../views/layout/top.php';
