<?php
// Default ay para sa local XAMPP (localhost, root, walang password, database na adelina3_hoa).
// Kung online hosting ang gamit, itakda ang HOA_DB_HOST, HOA_DB_USER, HOA_DB_PASSWORD
// at HOA_DB_NAME sa environment, o gumawa ng includes/db.local.php na nagse-set ng
// $host, $user, $pass at $dbname (huwag i-share ang file na iyon).
$host   = getenv('HOA_DB_HOST') ?: 'localhost';
$user   = getenv('HOA_DB_USER') ?: 'root';
$pass   = getenv('HOA_DB_PASSWORD') !== false ? (string) getenv('HOA_DB_PASSWORD') : '';
$dbname = getenv('HOA_DB_NAME') ?: 'adelina3_hoa';

if (is_file(__DIR__ . '/db.local.php')) {
    require __DIR__ . '/db.local.php';
}

// Sa PHP 8.1+, exception ang ibinabato ng mysqli; kailangan ito ng ibang page kaya hindi pinapatay.
try {
    $conn = new mysqli($host, $user, $pass, $dbname);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $exception) {
    // Sa error log lang ang detalye; hindi inilalantad sa user.
    error_log('Database connection failed: ' . $exception->getMessage());
    http_response_code(500);
    die('Hindi makakonekta sa database. Siguraduhing naka-start ang MySQL sa XAMPP at na-import ang database na "adelina3_hoa".');
}
ini_set('date.timezone', 'Asia/Manila');
