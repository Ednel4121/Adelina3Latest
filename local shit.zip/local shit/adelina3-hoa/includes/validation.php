<?php

function isValidPhilippineMobileNumber($number): bool
{
    if (!is_string($number) || preg_match('/\A09[0-9]{9}\z/', $number) !== 1) {
        return false;
    }

    return !hasUnrealisticDigitPattern(substr($number, 2), 8);
}

function isValidBlockLot($blockLot): bool
{
    if (!is_string($blockLot)) {
        return false;
    }

    $blockLot = trim($blockLot);
    if ($blockLot === '' || strlen($blockLot) > 50) {
        return false;
    }

    $digits = preg_replace('/[^0-9]/', '', $blockLot) ?? '';
    return $digits !== '' && !hasUnrealisticDigitPattern($digits, 5);
}

function hasUnrealisticDigitPattern(string $digits, int $minimumRepeatedDigits): bool
{
    if (preg_match('/([0-9])\1{' . ($minimumRepeatedDigits - 1) . ',}/', $digits) === 1) {
        return true;
    }

    foreach (['01234567', '12345678', '23456789', '98765432', '87654321', '76543210'] as $sequence) {
        if (strpos($digits, $sequence) !== false) {
            return true;
        }
    }

    return false;
}
