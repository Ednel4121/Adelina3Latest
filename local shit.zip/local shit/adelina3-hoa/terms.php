<?php
// Pampublikong pahina: Terms & Conditions ng Adelina 3 HOA portal.
// Walang login na kailangan para mabasa ito. Kung naka-login na ang user,
// ipakita ang Dashboard button sa halip na Mag-login/Mag-register.
require_once 'includes/helpers.php';
start_secure_session();
$loggedIn = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Terms and Conditions ng Adelina 3 Homeowners Association online portal.">
  <title>Terms &amp; Conditions | Adelina 3 Homeowners Association</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/style.css') ?>">
  <link rel="stylesheet" href="assets/css/redesign.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/redesign.css') ?>">
</head>
<body id="top" class="legal-page">
  <header class="legal-header">
    <a class="legal-brand" href="landing.php" aria-label="Adelina 3 Homeowners Association - Home">
      <img src="assets/images/logo.png?v=<?= (int) filemtime(__DIR__ . '/assets/images/logo.png') ?>" alt="Adelina 3 Homeowners Association logo">
    </a>
  </header>

  <main class="legal-wrap">
    <article class="legal-card">
      <?php if (!$loggedIn): ?>
        <a class="login-home-link" href="landing.php"><span aria-hidden="true">&larr;</span> <span data-i18n="legal.back">Bumalik sa landing page</span></a>
      <?php endif; ?>
      <h1>Terms &amp; Conditions</h1>
      <p class="muted" data-i18n="terms.updated">Huling update: Nobyembre 22, 2026</p>

      <h2 data-i18n="terms.s1h">1. Pagtanggap sa terms</h2>
      <p data-i18n="terms.s1p">Sa paggamit mo ng online portal ng <strong>Adelina 3 Homeowners Association</strong>, sumasang-ayon ka sa mga tuntuning ito. Kung hindi ka sumasang-ayon, huwag gamitin ang portal.</p>

      <h2 data-i18n="terms.s2h">2. Sino ang puwedeng gumamit</h2>
      <p data-i18n="terms.s2p">Ang portal ay para sa mga residente ng Adelina 3 at sa mga opisyal ng HOA (admin at HOA officer). Ang bawat account ay para sa iisang residente lamang.</p>

      <h2 data-i18n="terms.s3h">3. Ang iyong account</h2>
      <ul>
        <li data-i18n="terms.s3l1">Magbigay ng wasto at kumpletong impormasyon (buong pangalan, email, contact number, at Block &amp; Lot).</li>
        <li data-i18n="terms.s3l2">Panatilihing lihim ang iyong password. Ang password ay dapat 12 hanggang 64 characters.</li>
        <li data-i18n="terms.s3l3">Ang bagong account ay kailangan munang i-approve ng admin bago ka makapag-login.</li>
        <li data-i18n="terms.s3l4">Ikaw ang responsable sa lahat ng ginagawa gamit ang iyong account.</li>
        <li data-i18n="terms.s3l5">Maaaring burahin ng admin ang account na lumalabag sa mga tuntuning ito.</li>
      </ul>

      <h2 data-i18n="terms.s4h">4. Dues at payments</h2>
      <ul>
        <li data-i18n="terms.s4l1">Bayaran ang monthly dues sa oras.</li>
        <li data-i18n="terms.s4l2">Kapag nagbayad ka online, mag-upload ng malinaw na proof of payment.</li>
        <li data-i18n="terms.s4l3">Iva-validate ng admin ang bawat bayad (Approved o Rejected). Ang na-approve na bayad ay mamo-mark bilang Paid.</li>
        <li data-i18n="terms.s4l4">Kung na-reject ang bayad mo, maaari kang magbayad uli.</li>
      </ul>

      <h2 data-i18n="terms.s5h">5. Reservations</h2>
      <ul>
        <li data-i18n="terms.s5l1">Mag-book ng pasilidad sa pamamagitan ng portal.</li>
        <li data-i18n="terms.s5l2">Kailangan ng approval ng admin bago maging pinal ang reservation.</li>
        <li data-i18n="terms.s5l3">Hindi puwedeng mag-double-book sa iisang pasilidad, petsa, at oras.</li>
        <li data-i18n="terms.s5l4">Hindi puwedeng mag-book sa nakalipas na petsa o oras.</li>
        <li data-i18n="terms.s5l5">Kung hindi ka makakapunta, ipaalam agad sa admin.</li>
      </ul>

      <h2 data-i18n="terms.s6h">6. Complaints</h2>
      <ul>
        <li data-i18n="terms.s6l1">Mag-file ng complaint nang tapat at malinaw.</li>
        <li data-i18n="terms.s6l2">Mag-attach lang ng mga file na may kaugnayan sa complaint.</li>
        <li data-i18n="terms.s6l3">Tutugunan ng HOA officer ang complaint mo at makikita mo ang update sa portal.</li>
      </ul>

      <h2 data-i18n="terms.s7h">7. Announcements</h2>
      <p data-i18n="terms.s7p">Ang mga anunsyo na naka-post sa portal ay opisyal na pahayag ng HOA. Basahin ang mga ito nang regular para manatiling updated sa mga balita ng komunidad.</p>

      <h2 data-i18n="terms.s8h">8. Tamang paggamit</h2>
      <p data-i18n="terms.s8p">Bawal ang sumusunod:</p>
      <ul>
        <li data-i18n="terms.s8l1">Magbigay ng maling impormasyon o magpanggap na ibang tao;</li>
        <li data-i18n="terms.s8l2">Mag-upload ng nakakapinsalang file o nilalaman;</li>
        <li data-i18n="terms.s8l3">Subukang buksan ang datos ng ibang residente; at</li>
        <li data-i18n="terms.s8l4">Abusuhin ang portal o sirain ito.</li>
      </ul>

      <h2 data-i18n="terms.s9h">9. Pananagutan</h2>
      <p data-i18n="terms.s9p">Ang portal ay ibinibigay nang "as is" para sa komunidad ng Adelina 3. Sisikapin ng HOA na panatilihing gumagana at ligtas ang portal, ngunit hindi ito mananagot sa anumang pagkaantala, pagkawala ng datos, o pinsalang dulot ng hindi inaasahang pangyayari.</p>

      <h2 data-i18n="terms.s10h">10. Pagbabago sa terms</h2>
      <p data-i18n="terms.s10p">Maaaring baguhin ng HOA ang mga tuntuning ito paminsan-minsan. Ang pinakabagong bersyon ay palaging makikita sa pahinang ito, kasama ang petsa ng huling update. Ang patuloy mong paggamit ng portal pagkatapos ng pagbabago ay nangangahulugan ng iyong pagsang-ayon.</p>

      <h2 data-i18n="terms.s11h">11. Makipag-ugnayan</h2>
      <p data-i18n="terms.s11p">Kung may tanong ka tungkol sa mga tuntuning ito, makipag-ugnayan sa HOA admin sa pamamagitan ng portal.</p>
      <div class="legal-actions">
        <?php if ($loggedIn): ?>
          <a class="btn btn-primary" href="dashboard.php">Back to dashboard</a>
        <?php else: ?>
          <a class="btn landing-login" href="login.php" data-i18n="nav.login">Mag-login</a>
          <a class="btn btn-primary" href="register.php" data-i18n="nav.register">Mag-register</a>
        <?php endif; ?>
      </div>
    </article>
  </main>

  <footer class="landing-footer">
    <span>
      <a href="privacy.php">Privacy Policy</a>
      &middot;
      <a href="terms.php">Terms &amp; Conditions</a>
    </span>
    <span>&copy; <?= date('Y') ?> Adelina 3 HOA</span>
  </footer>
  <a class="back-to-top" href="#top" aria-label="Bumalik sa itaas">
    <span aria-hidden="true">&uarr;</span> Bumalik sa taas
  </a>
</body>
</html>
