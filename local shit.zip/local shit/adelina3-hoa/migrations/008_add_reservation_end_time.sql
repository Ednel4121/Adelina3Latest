ALTER TABLE reservations
  ADD COLUMN time_to TIME NULL AFTER time_reserved;
