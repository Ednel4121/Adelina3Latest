ALTER TABLE complaints
  ADD COLUMN other_specify VARCHAR(100) NULL AFTER category;
