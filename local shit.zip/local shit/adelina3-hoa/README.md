# Adelina 3 Homeowners Association System

Web-based HOA system: Resident at Household Management, Monthly Dues and Fees,
Announcements, Complaints, Facility Reservations, Dashboard at Reports.
Stack: HTML/CSS/JavaScript + PHP 8.2 + MySQL/MariaDB (XAMPP).

## Paano i-install (XAMPP)

1. I-extract ang `adelina3-hoa` folder sa `C:\xampp\htdocs\`.
2. Buksan ang XAMPP Control Panel at i-start ang **Apache** at **MySQL**.
3. Sa phpMyAdmin, gumawa ng database na `adelina3_hoa`. I-export ang database
   ng online site bilang SQL backup at i-import iyon sa bagong local database.
   Wala sa project files ang database backup, kaya kailangan itong kunin mula
   sa online hosting o sa sarili mong backup.
4. Patakbuhin ang migrations sa phpMyAdmin > SQL tab: UNA ang `migration.sql`
   ng DB-storage (kung hindi pa na-apply), tapos ang `migration.sql` ng
   version na ito (approval ng registration, login throttling, audit log).
   Kung wala pa ang `account_status` column sa `users`, patakbuhin din nang
   isang beses ang `migrations/006_add_account_status.sql`. Mananatiling
   approved ang existing accounts; pending ang mga bagong registration.
   Patakbuhin din nang isang beses ang
   `migrations/007_add_complaint_other_specify.sql` para ma-save ang custom na
   category kapag `Others` ang pinili.
   Patakbuhin din nang isang beses ang
   `migrations/008_add_reservation_end_time.sql` para masuportahan ang From at
   To time sa facility reservations.
5. Hindi na kailangan ang tatlong `hoa-*` upload folder — nasa database
   na naka-save ang mga ini-upload na file simula sa nakaraang version.
6. Buksan sa browser: `http://localhost/adelina3-hoa/`

By default, gumagamit ang local setup ng MySQL sa `localhost`, user na `root`,
walang password, at database na `adelina3_hoa` (default XAMPP settings). Kung
iba ang settings mo, itakda ang `HOA_DB_HOST`, `HOA_DB_USER`,
`HOA_DB_PASSWORD`, at `HOA_DB_NAME` sa PHP environment bago patakbuhin ang app.

## Mga account

- Ang mga account ay nasa database na (`users` table). Gumamit ng Forgot Password
  kung kailangan i-reset ang password ng resident account.
- Para sa OTP email, itakda ang `HOA_MAIL_PASSWORD` sa PHP environment. Huwag
  ilagay ang Gmail App Password sa source code o i-commit ito sa Git.

## Mga folder

- `includes/` - db.php (database), auth.php (login check), helpers.php (CSRF at
  session security), header.php, footer.php, validation.php, send_mail.php.
- `assets/css/style.css` - green design. `assets/js/script.js` - menu, search,
  image editor, confirmation dialogs.
- `migrations/` - mga SQL na in-apply na noon.
- `migration.sql` (kasama ng ZIP na ito) - approval ng registration,
  database-based login throttling, audit log, at index para sa
  reservations. Patakbuhin ito sa phpMyAdmin pagkatapos ng DB-storage
  migration kung hindi pa iyon na-apply.

## Tala

- Ang `.vscode/` folder ay hindi kasama sa ZIP na ito; pang-VS Code settings
  lang iyon at hindi kailangan sa XAMPP.
- Ang session ay nag-e-expire pagkatapos ng 30 minutong walang galaw.
- Ang bagong magre-register ay kailangang i-approve muna ng admin
  (tingnan ang "Naghihintay ng Approval" sa Residents page) bago
  makapag-login.
- Ang login ay naka-throttle: 5 maling pagtatangka = 10 minutong hintay
  (database-based, hindi malalampasan sa pag-clear ng cookies).
