<?php
// Pinapatotohanan ang account at inililipat ang matagumpay na naka-login sa dashboard.
require_once 'includes/helpers.php';
start_secure_session();

// Linisin ang anumang naiwang password-reset session (hal. mula sa ibang
// gumagamit ng parehong browser) para hindi ito magamit ng iba.
unset(
    $_SESSION['reset_user_id'],
    $_SESSION['reset_email'],
    $_SESSION['reset_otp_hash'],
    $_SESSION['reset_otp_expires'],
    $_SESSION['reset_otp_attempts'],
    $_SESSION['reset_otp_sent_at'],
    $_SESSION['reset_stage'],
    $_SESSION['reset_stage_expires']
);
require_once 'includes/db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$email = '';
$csrfToken = csrf_token();

// Simple login throttling: 5 maling pagtatangka = 10 minutong hintay.
$loginAttempts = (int) ($_SESSION['login_attempts'] ?? 0);
$loginBlockedUntil = (int) ($_SESSION['login_blocked_until'] ?? 0);

// Tinitingnan ang password hash mula sa database; hindi iniimbak ang password bilang plain text.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif ($loginBlockedUntil > time() || loginBlockedByDatabase($conn, strtolower(trim(post_string('email'))))) {
        $error = 'Masyadong maraming maling pagtatangka. Maghintay ng 10 minuto bago sumubok muli.';
    } else {
        $email = strtolower(trim(post_string('email')));
        $password = post_string('password');

        // Kapag hindi pa na-apply ang migration, walang account_status column;
        // tratuhin ang lahat ng account bilang approved para hindi ma-lock out.
        try {
            $stmt = $conn->prepare('SELECT user_id, full_name, email, password, role, account_status FROM users WHERE email = ?');
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
        } catch (mysqli_sql_exception $exception) {
            $stmt = $conn->prepare('SELECT user_id, full_name, email, password, role FROM users WHERE email = ?');
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            if (is_array($user)) {
                $user['account_status'] = 'approved';
            }
        }

        $passwordOk = false;
        $storedPassword = (string) ($user['password'] ?? '');
        if ($user && password_verify($password, $storedPassword)) {
            $passwordOk = true;
        } elseif (
            $user
            && !str_starts_with($storedPassword, '$2y$')
            && !str_starts_with($storedPassword, '$argon2')
            && $storedPassword !== ''
            && hash_equals($storedPassword, $password)
        ) {
            // Lumang plain-text password: i-verify ng isang beses lang dito,
            // saka agad itong papalitan ng hash sa ibaba.
            $passwordOk = true;
        }

        $accountPending = $passwordOk && (($user['account_status'] ?? 'approved') === 'pending');

        if ($accountPending) {
            // Tama ang password pero hindi pa na-approve ng admin ang account;
            // hindi ito binibilang na maling pagtatangka.
            $error = 'Naghihintay pa ng approval ng admin ang account mo. Makipag-ugnayan sa HOA.';
        } elseif ($passwordOk) {
            // I-upgrade ang luma o mahinang hash sa kasalukuyang default.
            if (password_needs_rehash($storedPassword, PASSWORD_DEFAULT)) {
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $rehashStmt = $conn->prepare('UPDATE users SET password = ? WHERE user_id = ?');
                $rehashStmt->bind_param('si', $newHash, $user['user_id']);
                $rehashStmt->execute();
            }
            unset($_SESSION['login_attempts'], $_SESSION['login_blocked_until']);
            recordLoginAttempt($conn, $email, true);
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            header('Location: dashboard.php');
            exit;
        }

        if (!$accountPending && !$passwordOk) {
            recordLoginAttempt($conn, $email, false);
            $loginAttempts++;
            $_SESSION['login_attempts'] = $loginAttempts;
            if ($loginAttempts >= 5) {
                $_SESSION['login_blocked_until'] = time() + 600;
                $_SESSION['login_attempts'] = 0;
            }
            $error = 'Mali ang email o password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | Adelina 3 Homeowners Association</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/style.css') ?>">
  <link rel="stylesheet" href="assets/css/redesign.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/redesign.css') ?>">
</head>
<body class="auth-page">
  <main class="login-wrap">
    <section class="login-card">
      <a class="login-home-link" href="landing.php" aria-label="Bumalik sa landing page">
        <span class="login-home-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M19 12H5m0 0 6.5-6.5M5 12l6.5 6.5"></path></svg></span>
        <span class="login-home-copy"><strong>Bumalik sa landing page</strong><small>Adelina 3 Homeowners Association</small></span>
        <span class="login-home-arrow" aria-hidden="true">↗</span>
      </a>
      <div class="login-brand-lockup"><img src="assets/images/logo-icon.png?v=<?= (int) filemtime(__DIR__ . '/assets/images/logo-icon.png') ?>" alt="Adelina 3 Homeowners Association logo"><div><h1>Adelina 3 Homeowners Association</h1><p class="muted">Sign in to access your resident portal</p></div></div>
      <?php if (($_GET['registered'] ?? '') === 'pending'): ?>
        <p class="alert alert-success" role="status">Matagumpay ang registration. Naghihintay pa ito ng approval ng admin bago ka makapag-login.</p>
      <?php elseif (isset($_GET['registered'])): ?>
        <p class="alert alert-success" role="status">Matagumpay ang registration. Mag-login para magpatuloy.</p>
      <?php endif; ?>
      <?php if (isset($_GET['password_reset'])): ?>
        <p class="alert alert-success" role="status">Napalitan na ang password. Maaari ka nang mag-login.</p>
      <?php endif; ?>
      <?php if (isset($_GET['session_expired'])): ?>
        <p class="alert" role="alert">Natapos ang session mo. Mag-login muli para magpatuloy.</p>
      <?php endif; ?>
      <?php if (isset($_GET['access_denied'])): ?>
        <p class="alert" role="alert">Hindi awtorisado ang role ng account. Makipag-ugnayan sa admin.</p>
      <?php endif; ?>
      <?php if ($error !== ''): ?>
        <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
      <?php endif; ?>
      <form action="login.php" method="post">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
        <label for="email">Email Address</label>
        <input id="email" type="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" placeholder="name@example.com" autocomplete="email" autocapitalize="none" spellcheck="false" required>
        <label for="password">Password <span class="login-password-rule">Use at least 12 characters</span></label>
        <div class="password-field">
          <input id="password" type="password" name="password" placeholder="Password" autocomplete="current-password" required>
          <button type="button" class="password-toggle" data-password-toggle="password" aria-label="Ipakita ang password" aria-pressed="false">
            <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path>
              <circle cx="12" cy="12" r="3"></circle>
            </svg>
          </button>
        </div>
        <div class="login-password-strength" aria-live="polite"><span class="login-strength-track"><i id="login-strength-bar"></i></span><span id="login-strength-text">Use at least 12 characters for a stronger password.</span></div>
        <button type="submit" class="btn btn-primary btn-block">Sign In to Portal <span aria-hidden="true">→</span></button>
      </form>
      <div class="login-links"><a href="forgot_password.php">Forgot password?</a><span>New resident? <a href="register.php">Register</a></span></div>
    </section>
  </main>
  <script src="assets/js/script.js?v=<?= (int) filemtime(__DIR__ . '/assets/js/script.js') ?>"></script>
</body>
</html>
