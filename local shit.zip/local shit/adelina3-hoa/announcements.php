<?php
// Pinapahintulutan ang staff na mag-post at inililista ang mga announcement para sa lahat.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Announcements';
$role = $_SESSION['role'] ?? 'resident';
$canPost = in_array($role, ['admin', 'officer'], true);
$error = '';
$message = $_SESSION['announcement_message'] ?? '';
$warning = $_SESSION['announcement_warning'] ?? '';
unset($_SESSION['announcement_message']);
unset($_SESSION['announcement_warning']);

// Pinoprotektahan ng CSRF token ang form laban sa request na hindi galing sa page na ito.
$csrfToken = csrf_token();
$title = '';
$body = '';
$category = 'General';
$allowedCategories = ['General', 'Emergency', 'Events', 'Maintenance', 'Reminder'];

// Tinatanggap lamang ang valid na post request mula sa awtorisadong staff.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (!$canPost) {
        http_response_code(403);
        $error = 'Admin o officer lang ang maaaring mag-post ng announcement.';
    } elseif (isset($_POST['delete_announcement'])) {
        $announcementId = filter_var(
            $_POST['announcement_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        if ($announcementId === false) {
            $error = 'Hindi wasto ang napiling announcement.';
        } else {
            $imageStmt = $conn->prepare('SELECT image_file FROM announcements WHERE announcement_id = ?');
            $imageStmt->bind_param('i', $announcementId);
            $imageStmt->execute();
            $announcement = $imageStmt->get_result()->fetch_assoc();

            $deleteStmt = $conn->prepare('DELETE FROM announcements WHERE announcement_id = ?');
            $deleteStmt->bind_param('i', $announcementId);
            $deleteStmt->execute();

            if ($deleteStmt->affected_rows > 0) {
                logAudit($conn, (int) $_SESSION['user_id'], 'delete_announcement', 'Binura ang announcement (announcement_id=' . $announcementId . ').');
            }

            $_SESSION['announcement_message'] = $deleteStmt->affected_rows > 0
                ? 'Matagumpay na natanggal ang announcement.'
                : 'Hindi natagpuan ang announcement na tatanggalin.';

            if ($deleteStmt->affected_rows > 0 && !empty($announcement['image_file'])) {
                $imageFile = $announcement['image_file'];
                if (!preg_match('/\A[a-f0-9]{32}\.(?:jpg|png|gif|webp)\z/i', $imageFile)) {
                    error_log('Announcement removal found an invalid image filename.');
                    $_SESSION['announcement_warning'] = 'Natanggal ang announcement, pero hindi ligtas na mabura ang image file nito.';
                } else {
                    $imagePath = dirname(__DIR__, 2)
                        . DIRECTORY_SEPARATOR . 'hoa-announcement-images'
                        . DIRECTORY_SEPARATOR . $imageFile;
                    if (is_file($imagePath) && !unlink($imagePath)) {
                        error_log('Announcement removal could not delete its image file.');
                        $_SESSION['announcement_warning'] = 'Natanggal ang announcement, pero hindi naalis ang image file nito.';
                    }
                }
            }

            header('Location: announcements.php');
            exit;
        }
    } else {
        $title = trim(post_string('title'));
        $body = trim(post_string('body'));
        $category = $_POST['category'] ?? 'General';
        if (!in_array($category, $allowedCategories, true)) {
            $category = 'General';
        }
        $imageUpload = $_FILES['image'] ?? null;
        $imageMimeExtensions = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
        ];
        $imageExtension = null;
        $imageMime = null;
        $uploadError = '';

        if ($imageUpload !== null) {
            if (!is_array($imageUpload) || !isset($imageUpload['error'])) {
                $uploadError = 'Hindi mabasa ang napiling image.';
            } elseif ($imageUpload['error'] !== UPLOAD_ERR_NO_FILE) {
                if ($imageUpload['error'] !== UPLOAD_ERR_OK) {
                    $uploadError = $imageUpload['error'] === UPLOAD_ERR_INI_SIZE
                        || $imageUpload['error'] === UPLOAD_ERR_FORM_SIZE
                        ? 'Hanggang 5 MB lang ang image.'
                        : 'Hindi na-upload ang image. Subukan muli.';
                } elseif (
                    !isset($imageUpload['tmp_name'], $imageUpload['size'])
                    || !is_string($imageUpload['tmp_name'])
                    || $imageUpload['size'] > 5 * 1024 * 1024
                    || !is_uploaded_file($imageUpload['tmp_name'])
                ) {
                    $uploadError = 'Hanggang 5 MB lang ang image.';
                } else {
                    $fileInfo = new finfo(FILEINFO_MIME_TYPE);
                    $imageMime = $fileInfo->file($imageUpload['tmp_name']);
                    if (!is_string($imageMime) || !isset($imageMimeExtensions[$imageMime])) {
                        $uploadError = 'JPG, PNG, GIF, o WEBP image lang ang puwedeng i-upload.';
                    } else {
                        $imageExtension = $imageMimeExtensions[$imageMime];
                    }
                }
            }
        }

        if ($title === '' || $body === '') {
            $error = 'Kailangan ang title at body ng announcement.';
        } elseif ($uploadError !== '') {
            $error = $uploadError;
        } else {
            $postedBy = (int) $_SESSION['user_id'];
            $imageFile = null;
            $imageData = null;

            if ($imageExtension !== null) {
                // Naka-save na sa database ang image, hindi na sa folder,
                // para hindi na kailangan ng folder permission sa hosting.
                $imageFile = bin2hex(random_bytes(16)) . '.' . $imageExtension;
                $imageData = file_get_contents($imageUpload['tmp_name']);
                if ($imageData === false) {
                    $error = 'Hindi na-save ang announcement image. Subukan muli.';
                    $imageFile = null;
                    $imageData = null;
                }
            }

            if ($error === '') {
                try {
                    $stmt = $conn->prepare(
                        'INSERT INTO announcements (title, body, category, posted_by, image_file, image_data, image_mime) VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );
                    $stmt->bind_param('sssisss', $title, $body, $category, $postedBy, $imageFile, $imageData, $imageMime);
                    $stmt->execute();

                    // Abiso sa lahat ng resident na may bagong announcement.
                    notifyAllResidents($conn, 'announcement', 'Bagong announcement', $title, 'announcements.php');

                    $_SESSION['announcement_message'] = 'Matagumpay na naipost ang announcement.';
                    header('Location: announcements.php');
                    exit;
                } catch (mysqli_sql_exception $exception) {
                    error_log('Announcement post failed: ' . $exception->getMessage());
                    $error = 'Hindi naipost ang announcement. Subukan muli.';
                }
            }
        }
    }
}

// Kinukuha ang filter mula sa URL; 'All' ang default at kahit anong hindi kilalang
// kategorya ay bumabalik sa 'All' para hindi mawalan ng laman ang listahan.
$filterCategory = $_GET['category'] ?? 'All';
if (!in_array($filterCategory, array_merge(['All'], $allowedCategories), true)) {
    $filterCategory = 'All';
}

// Ipinapakita ang pinakabago muna upang madaling makita ang bagong impormasyon.
$announcementPageSize = 10;
$announcementPage = paginationPage();
if ($filterCategory === 'All') {
    $announcementCount = (int) $conn->query('SELECT COUNT(*) AS total FROM announcements')->fetch_assoc()['total'];
    $announcementTotalPages = max(1, (int) ceil($announcementCount / $announcementPageSize));
    $announcementPage = min($announcementPage, $announcementTotalPages);
    $announcementOffset = ($announcementPage - 1) * $announcementPageSize;
    $announcements = $conn->query(
        'SELECT a.announcement_id, a.title, a.body, a.category, a.image_file, a.date_posted, u.full_name AS author
         FROM announcements a
         LEFT JOIN users u ON a.posted_by = u.user_id
         ORDER BY a.date_posted DESC, a.announcement_id DESC
         LIMIT ' . $announcementPageSize . ' OFFSET ' . $announcementOffset
    );
} else {
    $announcementCountStmt = $conn->prepare('SELECT COUNT(*) AS total FROM announcements WHERE category = ?');
    $announcementCountStmt->bind_param('s', $filterCategory);
    $announcementCountStmt->execute();
    $announcementCount = (int) $announcementCountStmt->get_result()->fetch_assoc()['total'];
    $announcementTotalPages = max(1, (int) ceil($announcementCount / $announcementPageSize));
    $announcementPage = min($announcementPage, $announcementTotalPages);
    $announcementOffset = ($announcementPage - 1) * $announcementPageSize;
    $filterStmt = $conn->prepare(
        'SELECT a.announcement_id, a.title, a.body, a.category, a.image_file, a.date_posted, u.full_name AS author
         FROM announcements a
         LEFT JOIN users u ON a.posted_by = u.user_id
         WHERE a.category = ?
         ORDER BY a.date_posted DESC, a.announcement_id DESC
         LIMIT ' . $announcementPageSize . ' OFFSET ' . $announcementOffset
    );
    $filterStmt->bind_param('s', $filterCategory);
    $filterStmt->execute();
    $announcements = $filterStmt->get_result();
}
$announcementPaginationParams = $filterCategory === 'All' ? [] : ['category' => $filterCategory];

require_once 'includes/header.php';
?>
<?php if ($canPost): ?>
  <div class="page-header"><h2>Announcements</h2></div>
<?php else: ?>
  <header class="resident-announcement-header">
    <span class="resident-announcement-eyebrow">COMMUNITY UPDATES</span>
    <h2>HOA Announcements &amp; Community Guidelines</h2>
    <p>Official announcements and important reminders for all Adelina 3 residents.</p>
  </header>
<?php endif; ?>
<?php if ($error !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($message !== ''): ?>
  <p class="alert alert-success" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($warning !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($warning, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($canPost): ?>
  <section class="card">
    <h3>Post Announcement</h3>
    <form class="form-grid" action="announcements.php" method="post" enctype="multipart/form-data" data-post-lock>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
      <div class="form-field form-field-wide">
        <label for="announcementTitle">Title</label>
        <input id="announcementTitle" type="text" name="title" value="<?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?>" maxlength="150" placeholder="Announcement title" required>
      </div>
      <div class="form-field form-field-wide">
        <label for="announcementBody">Body</label>
        <textarea id="announcementBody" name="body" rows="4" placeholder="Ilagay ang detalye ng announcement..." required><?= htmlspecialchars($body, ENT_QUOTES, 'UTF-8') ?></textarea>
      </div>
      <div class="form-field">
        <label for="announcementCategory">Kategorya</label>
        <select id="announcementCategory" name="category">
          <?php foreach ($allowedCategories as $allowedCategory): ?>
            <option value="<?= htmlspecialchars($allowedCategory, ENT_QUOTES, 'UTF-8') ?>"<?= $category === $allowedCategory ? ' selected' : '' ?>><?= htmlspecialchars($allowedCategory, ENT_QUOTES, 'UTF-8') ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-field form-field-wide">
        <label for="announcementImage">Image / Design (optional)</label>
        <input id="announcementImage" type="file" name="image" accept=".jpg,.jpeg,.png,.gif,.webp,image/jpeg,image/png,image/gif,image/webp">
        <small class="muted">JPG, PNG, GIF, o WEBP; hanggang 5 MB.</small>
        <div class="image-editor" data-image-editor data-image-input="announcementImage" data-max-output-size="5242880" hidden>
          <strong>Image preview at adjustment</strong>
          <div class="image-editor-preview"><canvas data-image-canvas aria-label="Preview ng edited announcement image"></canvas></div>
          <div class="image-editor-controls">
            <label>Crop
              <select data-image-crop>
                <option value="free">Buong image</option>
                <option value="1:1">Square (1:1)</option>
                <option value="4:3">Landscape (4:3)</option>
                <option value="16:9">Wide (16:9)</option>
              </select>
            </label>
            <label><span class="image-control-heading">Brightness <output data-image-brightness-value>100%</output></span>
              <input data-image-brightness type="range" min="50" max="150" value="100">
            </label>
            <label><span class="image-control-heading">Contrast <output data-image-contrast-value>100%</output></span>
              <input data-image-contrast type="range" min="50" max="150" value="100">
            </label>
          </div>
          <div class="image-editor-actions">
            <button type="button" class="btn btn-small" data-image-rotate="-90">I-rotate pakaliwa</button>
            <button type="button" class="btn btn-small" data-image-rotate="90">I-rotate pakanan</button>
            <button type="button" class="btn btn-small" data-image-reset>I-reset</button>
          </div>
          <small class="muted" data-image-status aria-live="polite">Hindi babaguhin ang upload hangga't hindi ina-adjust.</small>
        </div>
      </div>
      <div class="form-actions"><button type="submit" class="btn btn-primary" data-post-button><span data-post-label>Post Announcement</span></button></div>
    </form>
  </section>
  <section class="card">
    <h3>Latest Announcements</h3>
    <form class="category-filter" action="announcements.php" method="get">
      <label for="categoryFilterStaff">Kategorya</label>
      <select id="categoryFilterStaff" name="category" onchange="this.form.submit()">
        <option value="All"<?= $filterCategory === 'All' ? ' selected' : '' ?>>Lahat</option>
        <?php foreach ($allowedCategories as $allowedCategory): ?>
          <option value="<?= htmlspecialchars($allowedCategory, ENT_QUOTES, 'UTF-8') ?>"<?= $filterCategory === $allowedCategory ? ' selected' : '' ?>><?= htmlspecialchars($allowedCategory, ENT_QUOTES, 'UTF-8') ?></option>
        <?php endforeach; ?>
      </select>
      <noscript><button type="submit" class="btn btn-small">I-filter</button></noscript>
    </form>
    <div class="announcement-list">
      <?php if ($announcements->num_rows === 0): ?>
        <p class="muted">Wala pang announcements.</p>
      <?php else: ?>
        <?php while ($announcement = $announcements->fetch_assoc()): ?>
          <article class="announcement-item">
            <div class="announcement-content">
              <?php $announcementCategory = in_array($announcement['category'] ?? 'General', $allowedCategories, true) ? $announcement['category'] : 'General'; ?>
              <h4><?= htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8') ?> <span class="category-badge category-badge-<?= strtolower($announcementCategory) ?>"><?= htmlspecialchars($announcementCategory, ENT_QUOTES, 'UTF-8') ?></span></h4>
              <?php if (!empty($announcement['image_file'])): ?>
                <img class="announcement-image" src="download_announcement_image.php?id=<?= (int) $announcement['announcement_id'] ?>" alt="Announcement design" loading="lazy">
              <?php endif; ?>
              <p><?= nl2br(htmlspecialchars($announcement['body'], ENT_QUOTES, 'UTF-8')) ?></p>
              <span class="muted">
                <?= $announcement['date_posted'] ? htmlspecialchars(date('M d, Y g:i A', strtotime($announcement['date_posted'])), ENT_QUOTES, 'UTF-8') : '' ?>
                <?php if ($announcement['author']): ?> · <?= htmlspecialchars($announcement['author'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
              </span>
            </div>
            <form action="announcements.php" method="post" class="announcement-remove confirm-form" data-confirm="Tatanggalin ang announcement na ito. Magpatuloy?">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
              <input type="hidden" name="announcement_id" value="<?= (int) $announcement['announcement_id'] ?>">
              <button type="submit" name="delete_announcement" value="1" class="btn btn-small">Remove Announcement</button>
            </form>
          </article>
        <?php endwhile; ?>
      <?php endif; ?>
    </div>
    <?php renderPagination($announcementPage, $announcementTotalPages, $announcementPaginationParams); ?>
  </section>
<?php else: ?>
  <form class="category-filter" action="announcements.php" method="get">
    <label for="categoryFilterResident">Kategorya</label>
    <select id="categoryFilterResident" name="category" onchange="this.form.submit()">
      <option value="All"<?= $filterCategory === 'All' ? ' selected' : '' ?>>Lahat</option>
      <?php foreach ($allowedCategories as $allowedCategory): ?>
        <option value="<?= htmlspecialchars($allowedCategory, ENT_QUOTES, 'UTF-8') ?>"<?= $filterCategory === $allowedCategory ? ' selected' : '' ?>><?= htmlspecialchars($allowedCategory, ENT_QUOTES, 'UTF-8') ?></option>
      <?php endforeach; ?>
    </select>
    <noscript><button type="submit" class="btn btn-small">I-filter</button></noscript>
  </form>
  <section class="resident-announcement-grid" aria-label="Announcements">
    <?php if ($announcements->num_rows === 0): ?>
      <p class="resident-announcement-empty">Wala pang announcements.</p>
    <?php else: ?>
      <?php while ($announcement = $announcements->fetch_assoc()): ?>
        <article class="resident-announcement-card">
          <div class="resident-announcement-meta">
            <?php $announcementCategory = in_array($announcement['category'] ?? 'General', $allowedCategories, true) ? $announcement['category'] : 'General'; ?>
            <span class="resident-announcement-tag category-badge category-badge-<?= strtolower($announcementCategory) ?>"><?= htmlspecialchars($announcementCategory, ENT_QUOTES, 'UTF-8') ?></span>
            <?php if ($announcement['date_posted']): ?>
              <time datetime="<?= htmlspecialchars(date(DATE_ATOM, strtotime($announcement['date_posted'])), ENT_QUOTES, 'UTF-8') ?>">
                <?= htmlspecialchars(date('M d, Y', strtotime($announcement['date_posted'])), ENT_QUOTES, 'UTF-8') ?>
              </time>
            <?php endif; ?>
          </div>
          <h3><?= htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8') ?></h3>
          <?php if (!empty($announcement['image_file'])): ?>
            <img class="resident-announcement-image" src="download_announcement_image.php?id=<?= (int) $announcement['announcement_id'] ?>" alt="Announcement design" loading="lazy">
          <?php endif; ?>
          <p class="resident-announcement-body"><?= nl2br(htmlspecialchars($announcement['body'], ENT_QUOTES, 'UTF-8')) ?></p>
          <?php if ($announcement['author']): ?>
            <footer class="resident-announcement-footer">
              Posted by <?= htmlspecialchars($announcement['author'], ENT_QUOTES, 'UTF-8') ?>
            </footer>
          <?php endif; ?>
        </article>
      <?php endwhile; ?>
    <?php endif; ?>
  </section>
  <?php renderPagination($announcementPage, $announcementTotalPages, $announcementPaginationParams); ?>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
