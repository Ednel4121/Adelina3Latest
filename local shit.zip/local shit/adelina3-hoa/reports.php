<?php
// Pinagsasama ang payment, resident at complaint summaries para sa admin at officer.
require_once 'includes/auth.php';
require_once 'includes/db.php';

// Hindi inilalantad ang report data sa resident o ibang role na walang pahintulot.
$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['admin', 'officer'], true)) {
    http_response_code(403);
    $pageTitle = 'Reports';
    require_once 'includes/header.php';
    ?>
    <div class="page-header"><h2>Reports</h2></div>
    <p class="alert" role="alert">Admin at officer lang ang maaaring tumingin ng reports.</p>
    <?php
    require_once 'includes/footer.php';
    exit;
}

$pageTitle = 'Reports';
$error = '';
$reportMessage = $_SESSION['report_message'] ?? '';
unset($_SESSION['report_message']);
$csrfToken = csrf_token();
$reportTypes = [
    'payments' => 'Payments Report',
    'residents' => 'Residents Report',
    'complaints' => 'Complaints & Suggestions Report',
    'audit' => 'Audit Log',
];
$requestedReport = $_GET['report_type'] ?? '';
$selectedReport = is_string($requestedReport) && isset($reportTypes[$requestedReport])
    ? $requestedReport
    : '';

// Admin lang ang maaaring magbura ng audit log. Pagkatapos burahin, may
// isang entry na nananatili ("Binura ang audit log") para may record kung
// sino at kailan ito binura.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (isset($_POST['clear_audit_log'])) {
        if ($role !== 'admin') {
            http_response_code(403);
            $error = 'Admin lang ang maaaring magbura ng audit log.';
        } else {
            try {
                $conn->query('DELETE FROM audit_log');
                logAudit($conn, (int) $_SESSION['user_id'], 'clear_audit_log', 'Binura ang audit log.');
                $_SESSION['report_message'] = 'Nabura na ang audit log.';
                header('Location: reports.php');
                exit;
            } catch (mysqli_sql_exception $exception) {
                error_log('Clear audit log failed: ' . $exception->getMessage());
                $error = 'Hindi nabura ang audit log. Subukan muli.';
            }
        }
    }
}

// Kinukuha lamang ang dataset ng napiling report.
$payments = null;
$residents = null;
$complaints = null;
if ($selectedReport === 'payments') {
    $payments = $conn->query(
        'SELECT p.payment_id, p.amount, p.date_paid, p.status, p.description,
                u.full_name, r.block_lot
         FROM payments p
         JOIN residents r ON p.resident_id = r.resident_id
         JOIN users u ON r.user_id = u.user_id
         ORDER BY p.payment_id DESC'
    );
} elseif ($selectedReport === 'residents') {
    $residents = $conn->query(
        'SELECT u.full_name, u.email, u.contact_no, r.block_lot, r.household_members, r.move_in_date, r.status
         FROM residents r
         LEFT JOIN users u ON r.user_id = u.user_id
         ORDER BY r.block_lot'
    );
} elseif ($selectedReport === 'complaints') {
    $complaints = $conn->query(
        "SELECT c.report_type, c.category, c.other_specify, c.subject, c.details, c.status, c.date_filed, u.full_name, r.block_lot
         FROM complaints c
         JOIN residents r ON c.resident_id = r.resident_id
         JOIN users u ON r.user_id = u.user_id
         ORDER BY c.date_filed DESC, c.complaint_id DESC"
    );
}

require_once 'includes/header.php';
?>
<div class="page-header page-header-actions">
  <h2>Reports</h2>
</div>
<form class="card form-grid no-print" action="reports.php" method="get">
  <div class="form-field">
    <label for="reportType">Report Type</label>
    <select id="reportType" name="report_type" required>
      <option value="">-- Piliin ang report --</option>
      <?php foreach ($reportTypes as $reportKey => $reportLabel): ?>
        <option value="<?= htmlspecialchars($reportKey, ENT_QUOTES, 'UTF-8') ?>"<?= $selectedReport === $reportKey ? ' selected' : '' ?>><?= htmlspecialchars($reportLabel, ENT_QUOTES, 'UTF-8') ?></option>
      <?php endforeach; ?>
    </select>
  </div>
    <div class="form-actions d-flex gap-2 mt-3">
    <button type="submit" class="btn btn-primary">Generate Report</button>
    <?php if ($selectedReport !== ''): ?>
      <button id="printReportButton" type="button" class="btn btn-primary">Print Report</button>
    <?php endif; ?>
  </div>

</form>
<div class="report-print-header">
  <h2>Adelina 3 Homeowners Association</h2>
  <p><?= htmlspecialchars($selectedReport !== '' ? $reportTypes[$selectedReport] : 'Report', ENT_QUOTES, 'UTF-8') ?> — <?= htmlspecialchars(date('F d, Y'), ENT_QUOTES, 'UTF-8') ?></p>
</div>
<?php if ($selectedReport !== ''): ?>
  <div class="form-field no-print">
    <label for="reportSearch">Search this report</label>
    <input id="reportSearch" type="search" placeholder="Maghanap sa report..." autocomplete="off" aria-describedby="reportSearchNoMatch">
  </div>
  <p id="reportSearchNoMatch" class="muted no-print" role="status" hidden>Walang tugmang resulta.</p>
<?php endif; ?>
<?php if ($reportMessage !== ''): ?>
  <p class="alert alert-success no-print" role="status"><?= htmlspecialchars($reportMessage, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($error !== ''): ?>
  <p class="alert no-print" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($selectedReport === ''): ?>
  <p class="muted no-print">Pumili ng report type at pindutin ang Generate Report para makita at mai-print ang report na iyon lamang.</p>
<?php endif; ?>
<?php if ($selectedReport === 'payments'): ?>
<section class="card report-section">
  <h3>Payments Report</h3>
  <div class="table-wrap report-table-wrap">
    <table class="table report-table">
      <thead><tr><th>Resident</th><th>Block/Lot</th><th>Description</th><th>Amount</th><th>Date Paid</th><th>Status</th></tr></thead>
      <tbody>
        <?php if ($payments->num_rows === 0): ?>
          <tr><td colspan="6">Wala pang payment records.</td></tr>
        <?php else: ?>
          <?php while ($payment = $payments->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($payment['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($payment['block_lot'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($payment['description'], ENT_QUOTES, 'UTF-8') ?></td>
              <td>₱<?= number_format((float) $payment['amount'], 2) ?></td>
              <td><?= $payment['date_paid'] ? htmlspecialchars(date('M d, Y', strtotime($payment['date_paid'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
              <td><span class="badge <?= $payment['status'] === 'Paid' ? 'badge-paid' : 'badge-unpaid' ?>"><?= htmlspecialchars($payment['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
            </tr>
          <?php endwhile; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>
<?php if ($selectedReport === 'residents'): ?>
<section class="card report-section">
  <h3>Residents Report</h3>
  <div class="table-wrap report-table-wrap">
    <table class="table report-table">
      <thead><tr><th>Resident</th><th>Email</th><th>Block/Lot</th><th>Household</th><th>Move-in Date</th><th>Contact</th><th>Status</th></tr></thead>
      <tbody>
        <?php if ($residents->num_rows === 0): ?>
          <tr><td colspan="7">Wala pang resident records.</td></tr>
        <?php else: ?>
          <?php while ($resident = $residents->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($resident['full_name'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($resident['email'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($resident['block_lot'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars((string) $resident['household_members'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($resident['move_in_date'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($resident['contact_no'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($resident['status'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
            </tr>
          <?php endwhile; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>
<?php if ($selectedReport === 'complaints'): ?>
<section class="card report-section">
  <h3>Complaints &amp; Suggestions Report</h3>
  <div class="table-wrap report-table-wrap">
    <table class="table report-table">
      <thead><tr><th>Resident</th><th>Block/Lot</th><th>Type</th><th>Category</th><th>Subject/Address</th><th>Details</th><th>Date Filed</th><th>Status</th></tr></thead>
      <tbody>
        <?php if ($complaints->num_rows === 0): ?>
          <tr><td colspan="8">Wala pang complaint o suggestion records.</td></tr>
        <?php else: ?>
          <?php while ($complaint = $complaints->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($complaint['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($complaint['block_lot'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($complaint['report_type'] ?? 'Complaint', ENT_QUOTES, 'UTF-8') ?></td>
              <td>
                <?= htmlspecialchars($complaint['category'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                <?php if (($complaint['category'] ?? '') === 'Others' && !empty($complaint['other_specify'])): ?>
                  <div class="muted">Specify: <?= htmlspecialchars($complaint['other_specify'], ENT_QUOTES, 'UTF-8') ?></div>
                <?php endif; ?>
              </td>
              <td><?= htmlspecialchars($complaint['subject'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= nl2br(htmlspecialchars($complaint['details'] ?? '', ENT_QUOTES, 'UTF-8')) ?></td>
              <td><?= $complaint['date_filed'] ? htmlspecialchars(date('M d, Y', strtotime($complaint['date_filed'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
              <td><span class="badge <?= $complaint['status'] === 'Resolved' ? 'badge-paid' : ($complaint['status'] === 'Pending' ? 'badge-pending' : 'badge-progress') ?>"><?= htmlspecialchars($complaint['status'] ?? '', ENT_QUOTES, 'UTF-8') ?></span></td>
            </tr>
          <?php endwhile; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>
<?php
// Isinasalin ang audit action code sa nababasang Filipino (hal. ang
// 'delete_complaint' ay ipinapakita bilang 'Binura ang complaint').
$auditActionLabels = [
    'approve_resident' => 'Na-approve ang resident',
    'reject_resident' => 'Hindi na-approve ang resident',
    'remove_resident' => 'Tinanggal ang resident',
    'delete_announcement' => 'Binura ang announcement',
    'delete_complaint' => 'Binura ang complaint',
    'delete_payment' => 'Binura ang payment',
    'delete_reservation' => 'Binura ang reservation',
    'record_payment' => 'Nag-record ng payment',
    'validate_payment' => 'Na-validate ang payment',
    'approve_reservation' => 'Na-approve ang reservation',
    'reject_reservation' => 'Hindi na-approve ang reservation',
    'clear_audit_log' => 'Binura ang audit log',
    'clear_complaints' => 'Binura ang lahat ng complaint',
    'clear_payments' => 'Binura ang lahat ng payment',
];

// Ipinapakita ang pinakabagong audit log kung may audit_log table na.
$auditRows = null;
if ($selectedReport === 'audit') {
    try {
        $auditResult = $conn->query(
            'SELECT a.created_at, a.action, a.details, u.full_name
             FROM audit_log a
             LEFT JOIN users u ON a.user_id = u.user_id
             ORDER BY a.log_id DESC LIMIT 50'
        );
        $auditRows = $auditResult;
    } catch (mysqli_sql_exception $exception) {
        $auditRows = null;
    }
}
?>
<?php if ($selectedReport === 'audit' && $auditRows !== null): ?>
<section class="card report-section">
  <div class="card-head">
    <h3>Audit Log (pinakabagong 50)</h3>
    <?php if ($role === 'admin'): ?>
      <form action="reports.php" method="post" class="no-print" onsubmit="return confirm('Buburahin ang lahat ng audit log. Sigurado ka?');">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
        <button type="submit" name="clear_audit_log" value="1" class="btn btn-danger btn-small">Burahin ang Logs</button>
      </form>
    <?php endif; ?>
  </div>
  <div class="table-wrap report-table-wrap">
    <table class="table report-table">
      <thead><tr><th>Petsa/Oras</th><th>Gumawa</th><th>Aksyon</th><th>Detalye</th></tr></thead>
      <tbody>
        <?php if ($auditRows->num_rows === 0): ?>
          <tr><td colspan="4">Wala pang naitalang aksyon.</td></tr>
        <?php else: ?>
          <?php while ($audit = $auditRows->fetch_assoc()): ?>
            <?php
              // Nababasang aksyon (Filipino label) sa halip na raw code.
              $auditAction = $auditActionLabels[(string) ($audit['action'] ?? '')] ?? (string) ($audit['action'] ?? '');
              // Tinatanggal ang mga raw ID tulad ng "(complaint_id=5)" o
              // "resident_id=3" para madaling basahin ang detalye.
              $auditDetails = (string) ($audit['details'] ?? '');
              $auditDetails = preg_replace('/\s*\([^)]*_id=\d+[^)]*\)/i', '', $auditDetails) ?? $auditDetails;
              $auditDetails = preg_replace('/\b[a-z_]+_id=\d+,?\s*/i', '', $auditDetails) ?? $auditDetails;
              $auditDetails = preg_replace('/\(\s*\)/', '', $auditDetails) ?? $auditDetails;
              $auditDetails = trim((string) preg_replace('/\s+/', ' ', $auditDetails));
            ?>
            <tr>
              <td><?= $audit['created_at'] ? htmlspecialchars(date('M d, Y g:i A', strtotime($audit['created_at'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
              <td><?= htmlspecialchars($audit['full_name'] ?? 'System', ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($auditAction, ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($auditDetails, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>
          <?php endwhile; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
