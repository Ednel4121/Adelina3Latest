<?php
header('Location: adelina3-hoa/landing.php');
exit;
?>