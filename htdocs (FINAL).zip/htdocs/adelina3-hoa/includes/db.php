<?php

$host = "sql213.byethost10.com";
$user = "b10_43493255";
$pass = "@Adelina321";
$dbname = "b10_43493255_adelina3_hoa";

$conn = new mysqli($host, $user, $pass, $dbname);

// Hindi inilalantad ang detalye ng database error sa user; sa error log lang ito.
if ($conn->connect_error) {
    error_log('Database connection failed: ' . $conn->connect_error);
    http_response_code(500);
    die('Hindi makakonekta sa database. Subukan muli mamaya.');
}
ini_set('date.timezone', 'Asia/Manila');
?>