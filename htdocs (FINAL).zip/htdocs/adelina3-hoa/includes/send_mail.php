<?php

function smtpReadResponse($socket)
{
    $response = '';
    while (($line = fgets($socket, 515)) !== false) {
        $response .= $line;
        if (isset($line[3]) && $line[3] === ' ') {
            break;
        }
    }
    return $response;
}

function smtpCommand($socket, $command, $expectedCodes)
{
    if ($command !== '') {
        fwrite($socket, $command . "\r\n");
    }
    $response = smtpReadResponse($socket);
    $code = (int) substr($response, 0, 3);
    if (!in_array($code, $expectedCodes, true)) {
        throw new RuntimeException('Gmail SMTP error: ' . trim($response));
    }
    return $response;
}


function sendFallbackMail($recipient, $subject, $body)
{
    // Kapag hindi makakonekta sa Gmail SMTP (hal. naka-block ang port 465
    // sa free hosting), ipadala gamit ang mail() ng mismong server.
    // Noreply address ng live domain ang From para hindi ma-flag ang email.
    $headers = [
        'From: Adelina 3 HOA <noreply@adelina3.byethost10.com>',
        'Reply-To: Adelina 3 HOA <noreply@adelina3.byethost10.com>',
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
    ];
    if (!mail($recipient, $subject, $body, implode("\r\n", $headers))) {
        throw new RuntimeException('Hindi maipadala ang email gamit ang mail().');
    }
}

function sendGmailOtp($recipient, $otp)
{
    require_once __DIR__ . '/mail_config.php';
    require_once __DIR__ . '/mail_password.php';

    // Defense in depth: kahit may filter na sa caller, i-validate uli rito
    // para hindi maipasa ang may header-injection na address sa SMTP.
    if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('Hindi wasto ang email na padadalhan.');
    }

    try {
    if (($mailPassword ?? '') === '' || str_contains($mailPassword, 'PASTE_')) {
        throw new RuntimeException('Hindi pa naka-configure ang Gmail App Password.');
    }

    $socket = @fsockopen(
        'ssl://' . $mailConfig['host'],
        $mailConfig['port'],
        $errorNumber,
        $errorMessage,
        15
    );
    if (!$socket) {
        throw new RuntimeException('Hindi makakonekta sa Gmail SMTP.');
    }

    smtpReadResponse($socket);
    smtpCommand($socket, 'EHLO localhost', [250]);
    smtpCommand($socket, 'AUTH LOGIN', [334]);
    smtpCommand($socket, base64_encode($mailConfig['username']), [334]);
    smtpCommand($socket, base64_encode($mailPassword), [235]);
    smtpCommand($socket, 'MAIL FROM:<' . $mailConfig['username'] . '>', [250]);
    smtpCommand($socket, 'RCPT TO:<' . $recipient . '>', [250, 251]);
    smtpCommand($socket, 'DATA', [354]);

    $subject = 'Adelina 3 HOA Password Reset OTP';
    $body = "Your Adelina 3 HOA password reset code is: {$otp}\n\n"
        . "This code expires in 10 minutes. Do not share this code with anyone.";
    $headers = [
        'From: ' . $mailConfig['from_name'] . ' <' . $mailConfig['username'] . '>',
        'To: <' . $recipient . '>',
        'Subject: ' . $subject,
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
    ];
    fwrite($socket, implode("\r\n", $headers) . "\r\n\r\n" . $body . "\r\n.\r\n");
    smtpReadResponse($socket);
    smtpCommand($socket, 'QUIT', [221]);
    fclose($socket);
    } catch (Throwable $smtpError) {
        $fallbackSubject = 'Adelina 3 HOA Password Reset OTP';
        $fallbackBody = "Your Adelina 3 HOA password reset code is: {$otp}\n\n"
            . "This code expires in 10 minutes. Do not share this code with anyone.";
        sendFallbackMail($recipient, $fallbackSubject, $fallbackBody);
    }
}

function sendPasswordChangedEmail($recipient, $fullName)
{
    require_once __DIR__ . '/mail_config.php';
    require_once __DIR__ . '/mail_password.php';

    if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('Hindi wasto ang email na padadalhan.');
    }

    try {
    if (($mailPassword ?? '') === '' || str_contains($mailPassword, 'PASTE_')) {
        throw new RuntimeException('Hindi pa naka-configure ang Gmail App Password.');
    }

    $socket = @fsockopen(
        'ssl://' . $mailConfig['host'],
        $mailConfig['port'],
        $errorNumber,
        $errorMessage,
        15
    );
    if (!$socket) {
        throw new RuntimeException('Hindi makakonekta sa Gmail SMTP.');
    }

    smtpReadResponse($socket);
    smtpCommand($socket, 'EHLO localhost', [250]);
    smtpCommand($socket, 'AUTH LOGIN', [334]);
    smtpCommand($socket, base64_encode($mailConfig['username']), [334]);
    smtpCommand($socket, base64_encode($mailPassword), [235]);
    smtpCommand($socket, 'MAIL FROM:<' . $mailConfig['username'] . '>', [250]);
    smtpCommand($socket, 'RCPT TO:<' . $recipient . '>', [250, 251]);
    smtpCommand($socket, 'DATA', [354]);

    $subject = 'Adelina 3 HOA - Nagbago ang iyong password';
    $name = $fullName !== '' ? $fullName : 'Resident';
    $body = "Kumusta, {$name},

"
        . "Nagbago ang password ng iyong Adelina 3 HOA account.

"
        . "Kung ikaw ang nagpalit nito, huwag mo nang pansinin ang email na ito.

"
        . "Kung HINDI ikaw ang nagpalit, may ibang taong nakabukas ng iyong account. "
        . "Mag-reset ka agad ng password gamit ang Forgot Password dito:
https://adelina3.byethost10.com/adelina3-hoa/forgot_password.php

"
        . "O makipag-ugnayan sa HOA admin.

"
        . "Adelina 3 Homeowners Association";
    $headers = [
        'From: ' . $mailConfig['from_name'] . ' <' . $mailConfig['username'] . '>',
        'To: <' . $recipient . '>',
        'Subject: ' . $subject,
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
    ];
    fwrite($socket, implode("\r\n", $headers) . "\r\n\r\n" . $body . "\r\n.\r\n");
    smtpReadResponse($socket);
    smtpCommand($socket, 'QUIT', [221]);
    fclose($socket);
    } catch (Throwable $smtpError) {
        $fallbackName = $fullName !== '' ? $fullName : 'Resident';
        $fallbackSubject = 'Adelina 3 HOA - Nagbago ang iyong password';
        $fallbackBody = "Kumusta, {$fallbackName},\n\n"
            . "Nagbago ang password ng iyong Adelina 3 HOA account.\n\n"
            . "Kung ikaw ang nagpalit nito, huwag mo nang pansinin ang email na ito.\n\n"
            . "Kung HINDI ikaw ang nagpalit, may ibang taong nakabukas ng iyong account. "
            . "Mag-reset ka agad ng password gamit ang Forgot Password dito:\nhttps://adelina3.byethost10.com/adelina3-hoa/forgot_password.php\n\n"
            . "O makipag-ugnayan sa HOA admin.\n\n"
            . "Adelina 3 Homeowners Association";
        sendFallbackMail($recipient, $fallbackSubject, $fallbackBody);
    }
}
