<?php
// BABALA - HUWAG I-SHARE ANG FILE NA ITO.
// Nandito ang Gmail App Password na ginagamit sa pag-send ng OTP email.
// 1. Huwag itong i-screenshot, i-paste sa chat, o i-commit sa git.
// 2. PALITAN ITO AGAD ng bagong App Password dahil nalagay na ito sa ZIP file
//    na ipinasa noon: sa Google Account > Security > 2-Step Verification >
//    App passwords, gumawa ng bago at palitan ang value sa ibaba.
// 3. Para sa local XAMPP lang ang file na ito.
$mailPassword = 'yifeeymcdchahvpx';
